---
name: st-搜索
description: "ACG/二次元角色和作品资讯搜索技能。优先使用萌娘百科（Playwright 真实浏览器），其次 Fandom 维基，最后 WebSearch。当用户要搜动漫、游戏、小说、角色、人设、能力、作品资料时必须使用本技能。"
---

# ACG 资讯搜索技能

专门用于搜索 ACG/二次元领域的角色、作品资料，解决反爬和访问限制问题。

## 搜索优先级（严格按此顺序）

### 1. **萌娘百科**（第一优先级）

**⚠️ 2026年7月最新状态：所有 curl 方式已完全失效（Cloudflare 反爬升级）**

**只有使用 Playwright 真实浏览器才能绕过 Cloudflare 反爬。**

**访问方式：**
1. 使用 `mcp__plugin_playwright_playwright__browser_navigate` 导航到词条页面
2. 使用 `mcp__plugin_playwright_playwright__browser_evaluate` 执行提取脚本

**URL 格式（必须用 title 参数方式）：**
```
https://zh.moegirl.org.cn/index.php?title=中文词条名
```

**内容提取 JS 代码 v5.3（最终版，直接复制使用）：**

```javascript
async () => {
  // 第一步：展开所有折叠内容
  const expandButtons = document.querySelectorAll('.mw-collapsible-toggle, .mw-customtoggle, [role="button"]');
  for (const btn of expandButtons) {
    if (btn.textContent.includes('展开') || btn.textContent.includes('显示') || btn.getAttribute('aria-expanded') === 'false') {
      try { btn.click(); } catch (e) {}
    }
  }
  // 等待折叠内容展开
  await new Promise(resolve => setTimeout(resolve, 1200));
  
  const content = document.querySelector('#mw-content-text');
  if (!content) return { error: 'no content found' };
  
  // 移除杂质元素，但保留折叠内容内的正文
  const clone = content.cloneNode(true);
  const removeSelectors = [
    'script', 'style', '.navbox', '.mw-parser-output > .hatnote', '.mw-editsection',
    '.mw-collapsible-toggle', '.noprint', '.reference', '.mw-references-wrap',
    '.thumbinner', '.thumbcaption', '.thumb', '.external'
  ];
  removeSelectors.forEach(sel => {
    clone.querySelectorAll(sel).forEach(el => el.remove());
  });
  
  // 文本清理函数
  const cleanText = (text) => {
    return text
      .replace(/\s+/g, ' ')
      .replace(/\[\d+\]/g, '')
      .replace(/\{\{[^}]+\}\}/g, '')
      .replace(/\[编辑\]|\[展开\]|\[折叠\]|\[显示\]|\[隐藏\]/g, '')
      .replace(/AD加载中|all AD|来自.*广告|推广/g, '')
      .replace(/[""''｢｣]/g, '"')
      .replace(/[（(]([^）)]*)[）)]/g, (m, g1) => `（${g1.trim()}）`)
      .replace(/\s*[·•]\s*/g, '·')
      .trim();
  };
  
  // 判断是否为有效正文
  const isValidText = (text) => {
    if (text.length < 2) return false;
    if (/^(function|window\.|var |const |let |jQuery|\$\(|\.css\(|"use strict"|window\.RLQ)/.test(text)) return false;
    if (/\{\{|\}\}|\.playwright-mcp/.test(text)) return false;
    return true;
  };
  
  // 提取所有段落和标题
  const elements = clone.querySelectorAll('p, li, dd, h2, h3, h4');
  const sections = [];
  let currentSection = null;
  
  elements.forEach(el => {
    const tag = el.tagName.toLowerCase();
    const rawText = el.textContent.trim();
    const text = cleanText(rawText);
    
    if (!isValidText(text)) return;
    
    if (tag === 'h2' || tag === 'h3' || tag === 'h4') {
      sections.push({
        type: 'heading',
        level: tag,
        text: text
      });
      currentSection = text;
      return;
    }
    
    // 合并 Q&A
    const last = sections[sections.length - 1];
    if (text.startsWith('A：') && last && last.text.startsWith('Q：')) {
      last.text = last.text + '\n' + text;
      last.type = 'qa';
      return;
    }
    
    sections.push({
      type: text.startsWith('Q：') ? 'qa' : 'paragraph',
      level: currentSection,
      text: text
    });
  });
  
  // 标题层级
  const headings = sections
    .filter(s => s.type === 'heading')
    .map(h => ({ level: h.level, text: h.text }));
  
  // 生成结构化文本
  const structuredText = sections.map(sec => {
    if (sec.type === 'heading') {
      const marker = sec.level === 'h2' ? '##' : sec.level === 'h3' ? '###' : '####';
      return marker + ' ' + sec.text;
    }
    return sec.text;
  }).join('\n\n');
  
  // 可选：提取 Tab 图片链接（角色立绘）
  // 萌娘百科的 Tab 切换（平常/高专时期/幼年/新宿决战）只包含图片，不包含文字
  const tabImages = [];
  document.querySelectorAll('.TabContentText img').forEach((img, i) => {
    const label = document.querySelectorAll('.TabLabelText')[i]?.textContent?.trim() || `图片${i+1}`;
    tabImages.push({
      label: label,
      src: img.src,
      alt: img.alt || ''
    });
  });
  
  // 提取基本信息框（moe-infobox）
  // 萌娘百科的基本信息框包含本名、别号、发色、瞳色、身高、年龄、生日、星座、声优、萌点等结构化数据
  // 注意：必须使用精确选择器，避免匹配到编辑提示框
  const infobox = document.querySelector('.moe-infobox') || document.querySelector('.infobox3') || document.querySelector('div[class*="moe-infobox"]');
  const infoboxData = [];
  if (infobox) {
    // 跳过第一个子元素（Tab 切换区域）和"基本资料"标题
    const children = Array.from(infobox.children).slice(2);
    children.forEach(child => {
      const text = child.textContent.trim();
      if (text && text.length > 2) {
        // 格式：字段名\n值
        const lines = text.split('\n').filter(l => l.trim());
        if (lines.length >= 2) {
          const label = lines[0].trim();
          const value = lines.slice(1).join(' ').trim();
          infoboxData.push({ label, value });
        } else if (lines.length === 1 && text.length > 3) {
          // 单行的特殊情况（如"星座射手座"）
          infoboxData.push({ label: '信息', value: text });
        }
      }
    });
  }
  
  return {
    title: document.title,
    url: window.location.href,
    paragraphsCount: sections.filter(s => s.type !== 'heading').length,
    headings: headings,
    fullText: structuredText,
    infobox: infoboxData,  // 基本信息框结构化数据
    tabImages: tabImages  // 可选：角色立绘图片链接
  };
}
```

**v5.3 最终版说明：**

1. **自动展开折叠内容**
   - 点击所有「展开/显示」按钮
   - 等待1.5秒确保异步渲染完成

2. **清理杂质但保留正文**
   - 移除脚本、样式、导航栏、编辑链接、引用、广告残留、图片说明
   - **不再误删折叠内容内的正文段落**
   - **正确处理 TABLE 折叠容器内的段落**

3. **文本规范化**
   - 合并多余空白为单个空格
   - 移除引用角标 `[1]`、`[2]` 等
   - 统一引号为标准中文引号
   - 移除 `[编辑]`、`[展开]`、`[折叠]` 等按钮文字
   - 清理 "AD加载中"、"all AD"、"推广" 等广告残留

4. **Q&A 智能合并**
   - 将连续的 `Q：` 和 `A：` 合并为一段
   - 用换行分隔，便于阅读

5. **标题层级结构化**
   - h2/h3/h4 转换为 `## / ### / ####` Markdown 标题
   - 保留原文结构层次
   - **2字符标题正确识别**（修复 v5.0 的过滤问题）

6. **基本信息框提取（moe-infobox）**
   - 提取本名、别号、发色、瞳色、身高、年龄、生日、星座、声优、萌点等结构化数据
   - 返回 `infobox` 数组，包含 `label`（字段名）和 `value`（值）
   - **使用精确选择器**（`.moe-infobox` 或 `.infobox3`），避免误匹配编辑提示框

7. **Tab 图片提取（可选）**
   - 提取角色立绘图片链接（平常/高专时期/幼年/新宿决战）
   - 返回 `tabImages` 数组，包含标签和图片链接

8. **输出字段**
   - `title`：页面标题
   - `url`：页面地址
   - `paragraphsCount`：有效段落数
   - `headings`：标题层级数组
   - `fullText`：结构化完整原文
   - `infobox`：基本信息框结构化数据
   - `tabImages`：可选，角色立绘图片链接

**关于 Tab 切换结构（平常/高专时期/幼年/新宿决战）：**
- 这类 Tab 只包含角色立绘图片，**不包含文字内容**
- 如需提取图片链接，使用返回结果中的 `tabImages` 字段
- 文字内容已全部在标准段落中提取，无需额外处理

**整段原文保存：**
将 `fullText` 完整保存到文件中，不要概括、不要改写、不要遗漏折叠内容。保存时使用 Markdown 格式，保留 `##` 标题层级。如需保存基本信息框，可在文件开头添加 `infobox` 表格。如需保存图片链接，可添加 `tabImages` 表格。

**搜索技巧：**
- 不知道准确词条名时，先用 WebSearch 搜 "萌娘百科 角色名" 找到准确词条
- 角色名可能有多种译名，尝试最常用的译名

---

### 2. **Fandom 维基**（第二优先级）

Fandom 反爬非常宽松，直接用 `WebFetch` 或 `curl` 访问即可。

**常用 Fandom 维基：**
- 咒术回战: `https://jujutsu-kaisen.fandom.com/wiki/Character_Name`
- 进击的巨人: `https://attackontitan.fandom.com/wiki/Character_Name`
- 原神: `https://genshin-impact.fandom.com/wiki/Character_Name`

**访问方式：**
```bash
curl -sL "https://<work-name>.fandom.com/wiki/<Character_Name>" \
  -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
  --compressed
```

或使用 `WebFetch` 直接访问。

---

### 3. **WebSearch 全网搜索**（最后补充）

当萌娘百科和 Fandom 都找不到足够信息时，使用 WebSearch 补充搜索。

**搜索关键词建议：**
- `角色名 人设 能力 萌娘百科`
- `作品名 世界观 设定`
- `角色名 人物介绍`

---

## 通用知识搜索

如果用户搜索的不是 ACG 内容：
1. 优先使用英文维基百科（en.wikipedia.org）
2. 用 WebSearch 搜中文资料
3. **中文维基百科不可用（地区限制）**，需要代理才能正常访问

---

## 常见问题

**Q: 为什么直接访问中文路径不行？**
A: 服务器 URL 重写/编码问题，用 `index.php?title=` 参数方式可以绕过。

**Q: 百度百科为什么不推荐？**
A: 百度百科反爬更严格，需要携带完整的 Cookie 和更多 headers，不如用 WebSearch 方便。

**Q: 需要登录吗？**
A: 不需要。公开浏览内容全部匿名即可访问。

---

## 输出格式

根据用户需求选择输出方式：

### 方式一：整段原文提取（推荐，信息最完整）

当用户要求「完整提取」「原文」「全部内容」「不要概括」时，直接将 `fullText` 完整输出，保留 Markdown 标题层级。不要改写、不要概括、不要遗漏折叠内容。

```
# [角色/作品名] - 完整原文提取

**来源：** [访问的网址]
**提取时间：** [日期]
**有效段落数：** [段落数]

---

[完整原文内容，保留 ## / ### / #### 标题层级]
```

### 方式二：结构化整理（仅在用户明确要求摘要时使用）

当用户明确要求「整理」「总结」「提炼」时，才使用以下模板：

```
# 搜索结果：[角色/作品名]

## 基本信息
[从搜索结果提取的基本信息]

## 外貌/形象
[外貌描述内容]

## 性格特点
[性格描述内容]

## 能力/技能
[能力描述内容]

## 补充说明
[其他重要信息]

来源：[访问的网址]
```

如果某个字段没有找到，标注为「暂无资料」。

**默认优先使用方式一。** 因为萌娘百科的词条内容经过折叠展开后通常很长，强行套入方式二的模板会丢失大量剧情、设定细节和上下文，反而降低信息价值。
