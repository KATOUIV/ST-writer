---
name: st-EJS
description: >-
  SillyTavern EJS 动态加载控制器（@@preprocessing + getwi 按需加载世界书条目）的
  自检验、故障排查与部署校验。当用户反馈「绑了世界书但没效果 / AI 不知道术式设定 /
  AI 说这个世界没有 XX / 附加世界书没加载 / getwi 加载 0 条 / 控制器不执行」，
  或提到 @@preprocessing、getwi、KEY_INDEX、LOREBOOK_NAME、EjsTemplate、
  preload_worldinfo、蓝灯控制器 uid=167、二创库 / 同人创作库 动态加载，
  或要新建 / 导入 / 校验 / 修复这类 EJS 动态控制器世界书时，务必启用本 Skill。
  即使用户没直说「EJS」「校验清单」，只要现象指向「世界书条目动态加载失败」，也应启用。
---

# st-EJS · EJS 动态加载控制器自检验 Skill

为 SillyTavern「`@@preprocessing` + `getwi` 按需加载世界书条目」的二创库 / 同人创作库
提供**部署前校验 + 运行时排查 + 修复 SOP**。本 Skill 不复述方法论——
权威清单与真实案例都在 `references/` 中**原样保存**，按需 Read / 程序化读取即可。

## 核心机制（先理解，再排查）

```text
用户消息含关键词
  → 控制器条目（蓝灯 constant + @@preprocessing）在生成前执行 EJS
  → 匹配 KEY_INDEX → await getwi(世界书名, 条目名)
  → 被加载的 selective 条目（可处于禁用）正文进入提示词
  → AI 生成时看得见术式/设定正文
```

三个独立环节，任一失败都表现为「绑了世界书但没效果」：
**A 世界书挂载 / B EJS 插件 + `@@preprocessing` / C 控制器逻辑（读消息 → 匹配 → getwi）**。
排查必须**按顺序**，上一步失败先修上一步。

## 参考资料（references/ — 全部为本地原始资料，原样引用）

| 文件 | 用途 | 何时读 |
|------|------|--------|
| `references/EJS动态加载校验清单.md` | **权威清单**：机制速览、部署前校验、运行时 5 步排查、常见问题对照表、AI 修复 SOP、案例复盘、快速自检口令 | **任何 EJS 控制器排查/校验任务，第一步先完整 Read 它**，按其章节执行 |
| `references/咒术回战同人创作库_EJS优化版.json` | **真实参考案例**：128 条目导出（127 绿灯禁用 selective + 1 蓝灯控制器 uid=167）。学习正确的控制器写法、KEY_INDEX 结构、绿/蓝灯配比的具体范例 | 需要看真实控制器代码、KEY_INDEX 格式、条目字段时 |

清单与案例一一对应：清单里写的 uid=167、`LOREBOOK_NAME`、`lastUserMessage` fallback、
`getwi(LOREBOOK_NAME, …)`、127+1 配比，都能在这份 JSON 里找到实物。

## 工作流程

1. **先 Read** `references/EJS动态加载校验清单.md` 全文——它是本 Skill 的执行主体。
2. **判断场景**：
   - 新建 / 导入世界书 → 走清单 §2「部署前校验清单」。
   - 用户反馈「没效果」→ 走清单 §3「运行时校验清单」，从 Step 0 现象分类开始，按 Step 1→5 顺序。
   - 直接修复 → 用清单 §5「AI Agent 修复 SOP（复制即用）」。
3. **要看真实代码 / 字段**时，按下方方式读 JSON 案例，**对照**用户的世界书找差异。
4. 输出诊断时，引用清单里的**判定标准**（如 `evalTemplate` 输出 `outLen > 500` 且含术式正文 = 控制器正常；`outLen ≈ 17` = 关键词未匹配），不要凭感觉下结论。

## 读取 JSON 案例的正确方式（重要）

`咒术回战同人创作库_EJS优化版.json` 约 1.7MB，**禁止整文件 Read**（会爆上下文）。
用 `node -e` 按需抽取。控制器在 `entries`（对象，值为条目数组元素），uid=167：

```bash
# 抽取控制器 EJS 全文（正确写法的范例：LOREBOOK_NAME + lastUserMessage fallback + getwi(名,条目)）
cd "<json 所在目录>" && node -e '
const fs=require("fs");
const d=JSON.parse(fs.readFileSync("咒术回战同人创作库_EJS优化版.json","utf8"));
const arr=Object.values(d.entries);
const c=arr.find(x=>x.uid===167);
console.log(c.content);
'

# 校验绿/蓝灯配比（应为 disable=false 仅 1 条 = 控制器；constant=true 仅 1 条）
node -e '
const fs=require("fs");
const arr=Object.values(JSON.parse(fs.readFileSync("咒术回战同人创作库_EJS优化版.json","utf8")).entries);
console.log("总条目:",arr.length,
  "| 启用(disable=false):",arr.filter(x=>x.disable===false).length,
  "| 蓝灯(constant=true):",arr.filter(x=>x.constant===true).length);
'
```

注意字段映射：清单里说的「蓝灯 constant」对应 JSON 的 `constant: true`；
「绿灯禁用」对应 `disable: true` + `constant: false`；`name` 字段（非 `comment`）才是 `getwi` 的查找键。

## 高频坑（详见清单，这里只做指针）

- **附加世界书场景**：`getwi('条目名')` 会误查主要世界书 → 必须 `getwi(LOREBOOK_NAME, '条目名')`，且 `LOREBOOK_NAME` 与 ST 内世界书名**完全一致**。（清单 §2.2）
- **读消息**：`@@preprocessing` 阶段 `getChatMessages(-1,-1,'user')` 常返回空 → 必须 fallback 到 `lastUserMessage`。（清单 §2.3，本次案例核心修复）
- **插件开关**：`preload_worldinfo_enabled` + `generate_enabled` 须为 `true`。（清单 §2.4 / §3 Step 3）
- **修复前的旧楼层不会回溯更新** → 需 `/regenerate` 或发新消息。（清单 §3 Step 0 / §4）
- **`name` ≠ KEY_INDEX.name** → getwi 找不到条目。（清单 §4 #3）

不要把方法论复制进本文件——遇到细节一律回 `references/EJS动态加载校验清单.md` 查权威表述。
