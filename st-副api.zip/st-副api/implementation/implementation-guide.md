# 副 API 脚本实现指南

本文件提供一套通用、可替换卡名的 TypeScript / Vue 模板。把对应代码块复制到 `多API/脚本/` 下同名文件，再改 `card-config.ts` 中的 `{{CARD_NAME}}`、`{{SLUG}}`、`{{TRIGGER_TAG}}` 即可。

## 文件清单

```text
多API/脚本/
├── index.ts              # 入口：等待 MVU → 初始化
├── card-config.ts        # 卡名/世界书条目/prompt 路径配置
├── orchestrator.ts       # 监听生成事件，触发副 API
├── api-client.ts         # generateRaw + 提取 UpdateVariable
├── merge-message.ts      # 合并正文与变量块
├── prompt-builder.ts     # 组装副 API ordered_prompts
├── lore-cache.ts         # ?raw 导入格式与 MVU 三件套
├── worldbook-toggle.ts   # single/dual 世界书切换
├── settings.ts           # zod schema + 持久化
├── settings-ui.ts        # 挂载设置面板
└── SettingsPanel.vue     # 面板 UI
```

## card-config.ts

```typescript
/** 复制本文件后只改 branding/worldbookEntries/loreFiles/triggerTag */
export const cardConfig = {
  branding: {
    panelTitle: '{{CARD_NAME}} · 多 API',
    toastPrefix: '{{CARD_NAME}}多API',
    globalSettingsKey: '{{CARD_NAME}}多API',
    scriptId: '{{SLUG}}-dual-api',
  },

  worldbookEntries: {
    singleFormat: '[格式]单一api模式',
    dualMainFormat: '[格式]多api主api',
    varList: '变量列表',
    varRules: '[mvu_update]变量更新规则',
    varOutput: '[mvu_update]变量输出格式',
    initvar: 'MVU初始变量',
  },

  /** 路径均相对 多API/脚本/ */
  loreFiles: {
    singleFormat: '../格式/单一api.txt',
    dualMainFormat: '../格式/多api主api.txt',
    secondaryFormat: '../格式/多api副api.txt',
    varList: '../../MVU/变量列表.txt',
    varRules: '../../MVU/变量更新规则.yaml',
    varOutput: '../../MVU/变量输出格式.yaml',
  },

  triggerTag: '{{TRIGGER_TAG}}',
  variableTag: 'UpdateVariable',
  statusPlaceholder: 'StatusPlaceHolderImpl',
  secondaryGenPrefix: '{{SLUG}}-secondary-',

  sampleScene:
    '（替换为本卡世界观的一小段 story_scene 正文，50～150 字）',
} as const;

export type CardConfig = typeof cardConfig;
```

## index.ts

```typescript
import { cardConfig } from './card-config';
import { initSettings, reloadSettingsFromStorage } from './settings';
import { initOrchestrator } from './orchestrator';
import { mountSettingsPanel } from './settings-ui';

async function main() {
  await waitGlobalInitialized('Mvu');
  initSettings(cardConfig);
  reloadSettingsFromStorage();
  initOrchestrator(cardConfig);
  mountSettingsPanel(cardConfig);
  console.log(`[${cardConfig.branding.toastPrefix}] 已加载`);
}

main().catch((e) => console.error(`[${cardConfig.branding.toastPrefix}] 初始化失败`, e));
```

## orchestrator.ts

```typescript
import type { CardConfig } from './card-config';
import { runSecondaryApi } from './api-client';
import { mergeUpdateVariable, extractTag } from './merge-message';
import { getSettings } from './settings';

export function initOrchestrator(config: CardConfig) {
  eventOn(tavern_events.GENERATION_ENDED, async ({ message_id }: { message_id: number }) => {
    const settings = getSettings();
    if (settings.apiMode !== 'dual') return;

    const [msg] = getChatMessages(message_id, { include_swipes: true });
    if (!msg) return;

    const mainRaw = msg.message;
    const storyScene = extractTag(mainRaw, config.triggerTag);
    if (!storyScene) {
      console.warn(`[${config.branding.toastPrefix}] 主 API 未输出 ${config.triggerTag}`);
      return;
    }

    const uv = await runSecondaryApi(config, storyScene, message_id);
    if (!uv) {
      console.warn(`[${config.branding.toastPrefix}] 副 API 未返回 ${config.variableTag}`);
      return;
    }

    const merged = mergeUpdateVariable(mainRaw, uv, config);
    await setChatMessages(
      [{ message_id, message: merged, swipe_id: msg.swipe_id, swipes: msg.swipes }],
      { refresh: 'affected' },
    );

    const messages = getChatMessages();
    const idx = messages.findIndex((m) => m.message_id === message_id);
    const prevId = idx > 0 ? messages[idx - 1].message_id : message_id;
    const oldData = Mvu.getMvuData({ type: 'message', message_id: prevId });
    const newData = await Mvu.parseMessage(merged, klona(oldData));
    await Mvu.replaceMvuData(newData, { type: 'message', message_id });
    eventEmit(tavern_events.MESSAGE_UPDATED, message_id);
  });
}
```

## api-client.ts

```typescript
import type { CardConfig } from './card-config';
import { buildSecondaryPrompts } from './prompt-builder';
import { extractTag } from './merge-message';

export async function runSecondaryApi(
  config: CardConfig,
  storyScene: string,
  messageId: number,
): Promise<string> {
  const settings = getSettings();
  const secondary = settings.secondary;
  if (!secondary?.baseUrl?.trim() || !secondary?.model?.trim()) {
    console.warn(`[${config.branding.toastPrefix}] 副 API 未配置 Base URL 或 Model`);
    return '';
  }

  const prompts = buildSecondaryPrompts(config, storyScene, messageId);
  const raw = await generateRaw({
    should_silence: true,
    should_stream: false,
    generation_id: `${config.secondaryGenPrefix}${messageId}-${Date.now()}`,
    ordered_prompts: prompts,
    custom_api: {
      apiurl: secondary.baseUrl,
      key: secondary.apiKey,
      model: secondary.model,
      source: secondary.source ?? 'custom',
      temperature: secondary.temperature ?? 0.7,
      max_tokens: secondary.maxTokens ?? 2048,
    },
  });

  return extractTag(raw, config.variableTag);
}
```

## merge-message.ts

```typescript
import type { CardConfig } from './card-config';

export function extractTag(raw: string, tag: string): string {
  const match = raw.match(new RegExp(`<${tag}>([\\s\\S]*?)<\\/${tag}>`, 'i'));
  return match ? match[1].trim() : '';
}

export function stripTag(raw: string, tag: string): string {
  return raw.replace(new RegExp(`<${tag}>[\\s\\S]*?<\\/${tag}>`, 'gi'), '').trim();
}

export function mergeUpdateVariable(
  mainRaw: string,
  uvContent: string,
  config: CardConfig,
): string {
  const tag = config.variableTag;
  const cleanMain = stripTag(mainRaw, tag);
  return `${cleanMain}\n<${tag}>\n${uvContent}\n</${tag}>`;
}
```

## prompt-builder.ts

```typescript
import type { CardConfig } from './card-config';
import { getLore } from './lore-cache';
import { getSettings } from './settings';

export function buildSecondaryPrompts(
  config: CardConfig,
  storyScene: string,
  _messageId: number,
) {
  const settings = getSettings();
  const advanced = settings.advanced ?? {};
  const parts = [
    { role: 'system', content: getLore('secondaryFormat') },
    { role: 'system', content: getLore('varRules') },
    { role: 'system', content: getLore('varList') },
    { role: 'system', content: getLore('varOutput') },
  ];

  if (advanced.injectStatData) {
    const vars = getVariables({ type: 'message' });
    const stat = _.get(vars, 'stat_data', {});
    parts.push({ role: 'system', content: `当前 stat_data:\n${JSON.stringify(stat, null, 2)}` });
  }

  parts.push({
    role: 'user',
    content: `本轮 <${config.triggerTag}> 正文：\n${storyScene}\n\n请仅输出 <${config.variableTag}> 块，不要输出其他主 API 标签。`,
  });

  return parts;
}
```

## lore-cache.ts

```typescript
import type { CardConfig } from './card-config';

import secondaryFormat from '../格式/多api副api.txt?raw';
import varList from '../../MVU/变量列表.txt?raw';
import varRules from '../../MVU/变量更新规则.yaml?raw';
import varOutput from '../../MVU/变量输出格式.yaml?raw';

const cache: Record<string, string> = {
  secondaryFormat,
  varList,
  varRules,
  varOutput,
};

export function getLore(key: keyof typeof cache): string {
  return cache[key] ?? '';
}
```

## worldbook-toggle.ts

```typescript
import type { CardConfig } from './card-config';

export async function ensureWorldbookForMode(
  config: CardConfig,
  mode: 'single' | 'dual',
) {
  const wbName = getCharWorldbookNames('current').primary;
  if (!wbName) return;

  const controlled = Object.values(config.worldbookEntries);
  await updateWorldbookWith(wbName, (entries) =>
    entries.map((e) => {
      if (!controlled.includes(e.name)) return e;
      const enabled =
        e.name === config.worldbookEntries.singleFormat
          ? mode === 'single'
          : e.name === config.worldbookEntries.dualMainFormat
            ? mode === 'dual'
            : mode === 'single';
      return { ...e, enabled };
    }),
  );
}
```

## settings.ts

```typescript
import { z } from 'zod';
import type { CardConfig } from './card-config';

const channelSchema = z.object({
  name: z.string(),
  baseUrl: z.string(),
  apiKey: z.string(),
  model: z.string(),
  source: z.string().default('custom'),
  temperature: z.number().default(0.7),
  maxTokens: z.number().default(2048),
});

const settingsSchema = z.object({
  apiMode: z.enum(['single', 'dual']).default('single'),
  savedChannels: z.array(channelSchema).default([]),
  secondary: channelSchema.optional(),
  advanced: z.object({
    injectStatData: z.boolean().default(true),
    injectChatHistoryDepth: z.number().default(0),
    fallbackOnSecondaryFail: z.enum(['retry', 'single-shot-vars', 'none']).default('retry'),
    maxSecondaryRetries: z.number().default(1),
    showDebugToast: z.boolean().default(false),
  }).default({}),
});

export type Settings = z.infer<typeof settingsSchema>;

let _settings: Settings = settingsSchema.parse({});
let _config: CardConfig;

export function initSettings(config: CardConfig) {
  _config = config;
}

export function getSettings(): Settings {
  return _settings;
}

export function persistSettings(s: Settings) {
  _settings = settingsSchema.parse(s);
  replaceVariables(_settings, { type: 'script', script_id: getScriptId() });
  insertOrAssignVariables(
    { [_config.branding.globalSettingsKey]: _settings },
    { type: 'global' },
  );
}

export function reloadSettingsFromStorage() {
  const global = getVariables({ type: 'global' })[_config.branding.globalSettingsKey] ?? {};
  const script = getVariables({ type: 'script', script_id: getScriptId() }) ?? {};
  _settings = settingsSchema.parse({ ...global, ...script });
}
```

## settings-ui.ts

```typescript
import { createApp } from 'vue';
import SettingsPanel from './SettingsPanel.vue';
import { createScriptIdDiv, teleportStyle } from '@util/script';
import type { CardConfig } from './card-config';

let app: ReturnType<typeof createApp> | null = null;

export function mountSettingsPanel(config: CardConfig) {
  const container = createScriptIdDiv(config.branding.scriptId);
  const target = document.querySelector('#extensions_settings2');
  if (!target) return;

  target.appendChild(container);
  app = createApp(SettingsPanel, { config });
  app.mount(container);
  teleportStyle(container);

  $(window).on('pagehide', () => {
    app?.unmount();
    app = null;
  });
}
```

## SettingsPanel.vue（最简版）

```vue
<template>
  <div class="dual-api-panel">
    <h3>{{ config.branding.panelTitle }}</h3>
    <label>模式</label>
    <select v-model="settings.apiMode" @change="onModeChange">
      <option value="single">单一 API</option>
      <option value="dual">多 API</option>
    </select>

    <div v-if="settings.apiMode === 'dual'">
      <label>Base URL</label>
      <input v-model="secondary.baseUrl" />
      <label>API Key</label>
      <input v-model="secondary.apiKey" type="password" />
      <label>Model</label>
      <input v-model="secondary.model" />
      <button @click="test">测一下副 API</button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { reactive, watch } from 'vue';
import type { CardConfig } from './card-config';
import { getSettings, persistSettings } from './settings';
import { ensureWorldbookForMode } from './worldbook-toggle';
import { runSecondaryApi } from './api-client';

const props = defineProps<{ config: CardConfig }>();
const settings = reactive(getSettings());
const secondary = reactive(settings.secondary ?? { baseUrl: '', apiKey: '', model: '' });

function onModeChange() {
  ensureWorldbookForMode(props.config, settings.apiMode);
  persistSettings({ ...settings, secondary: { ...secondary } });
}

async function test() {
  const uv = await runSecondaryApi(props.config, props.config.sampleScene, -1);
  alert(uv ? '测试通过' : '测试失败');
}

watch([settings, secondary], () => {
  persistSettings({ ...settings, secondary: { ...secondary } });
}, { deep: true });
</script>

<style scoped>
.dual-api-panel { display: flex; flex-direction: column; gap: 8px; padding: 8px; }
</style>
```

## index.yaml 注册片段

```yaml
世界书:
  - 名称: "[格式]单一api模式"
    启用: true
    激活策略: { 类型: 蓝灯 }
    插入位置:
      类型: 指定深度
      角色: 系统
      深度: 0
      顺序: 4980
    文件: 多API\格式\单一api

  - 名称: "[格式]多api主api"
    启用: false
    激活策略: { 类型: 蓝灯 }
    插入位置:
      类型: 指定深度
      角色: 系统
      深度: 0
      顺序: 4981
    文件: 多API\格式\多api主api

  - 名称: "变量列表"
    启用: true
    文件: MVU\变量列表

  - 名称: "[mvu_update]变量更新规则"
    启用: true
    文件: MVU\变量更新规则

  - 名称: "[mvu_update]变量输出格式"
    启用: true
    文件: MVU\变量输出格式

脚本:
  - 名称: 多API
    id: "{{SLUG}}-dual-api"
    启用: true
    按钮: false
    文件: 脚本发布/{{SLUG}}-dual-api.js
```

把 `{{SLUG}}` 替换为实际英文 slug。
