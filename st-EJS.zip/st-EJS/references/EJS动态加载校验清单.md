# EJS 动态加载控制器 · 故障排查与校验清单

> **适用对象**：`@@preprocessing` + `getwi` 按需加载世界书条目的二创库 / 同人创作库。  
> **典型案例**：`咒术回战同人创作库_EJS优化版`（128 条：127 绿灯禁用 + 1 蓝灯控制器 uid=167）。  
> **读者**：人类维护者 + AI Agent（按本文顺序排查，勿跳过前置条件）。

---

## 1. 机制速览（AI 必须先理解）

```text
用户消息含关键词
    ↓
控制器条目（蓝灯 constant + @@preprocessing）在生成前执行 EJS
    ↓
匹配 KEY_INDEX → await getwi(世界书名, 条目名)
    ↓
被加载的 selective 条目（可处于「禁用」）正文进入提示词
    ↓
AI 生成时能看见术式/设定正文
```

**三个独立环节，任一失败都会表现为「绑了世界书但没效果」：**

| 环节 | 失败时表象 |
|------|------------|
| A. 世界书挂载 | 控制器根本不会参与扫描 |
| B. EJS 插件 / `@@preprocessing` | 控制器不执行或输出为空 |
| C. 控制器逻辑（读消息 / 匹配 / getwi） | 控制器执行了但加载 0 条 |

---

## 2. 部署前校验清单（新建或导入时）

### 2.1 世界书结构

- [ ] **仅 1 条蓝灯控制器**（`constant: true`，`enabled: true`），内容以 `@@preprocessing` 开头
- [ ] **其余术式条目为绿灯 selective 且 `enabled: false`**（由 `getwi` 加载，不要指望 UI 里手动开灯）
- [ ] 控制器内 `KEY_INDEX[].name` 与条目 **`name` 字段**（不是 comment 备注）一致，否则 `getwi` 找不到
- [ ] `KEY_INDEX` 中 `keys` 与用户可能输入的词一致（含别名、简称，如「十影法」「十种影法术」）
- [ ] 控制器使用 **`<%- await getwi(...) %>`**，不是 `<%=`，且必须带 `await`

### 2.2 附加世界书 + getwi 世界书名（高频坑）

当 EJS 世界书挂在角色的 **附加世界书**，而 **主要世界书** 是另一本（如沙盒主世界书）时：

- [ ] **禁止**只写 `getwi('条目名')`（会只在主要世界书里查找 → 永远空）
- [ ] **必须**写 `getwi('咒术回战同人创作库_EJS优化版', '条目名')` 或等价显式世界书名
- [ ] 控制器顶部定义 `LOREBOOK_NAME` 常量，与 ST 中世界书名称 **完全一致**（含空格、下划线）

```javascript
var LOREBOOK_NAME = '咒术回战同人创作库_EJS优化版';
// ...
<%- await getwi(LOREBOOK_NAME, matchedNames[mi]) %>
```

### 2.3 读取用户消息（本次修复的核心）

在 `@@preprocessing` 阶段，`getChatMessages(-1, -1, 'user')` **可能返回空数组**，但 EJS 上下文里 **`lastUserMessage` 有值**。

- [ ] 控制器必须 **fallback 到 `lastUserMessage`**
- [ ] 可选：上下文 fallback 到 `lastCharMessage`（近期 AI 回复里也含关键词时）

```javascript
if (typeof messageText === 'undefined') {
  var userMessages = getChatMessages(-1, -1, 'user');
  var messageText = userMessages.length > 0
    ? userMessages[userMessages.length - 1].message
    : (typeof lastUserMessage !== 'undefined' ? lastUserMessage : '');
}

if (typeof ctxText === 'undefined') {
  var recent = getChatMessages(-3, -1);
  var ctxText = recent.map(function(m) { return m.message || ''; }).join(' ');
  if (!ctxText && typeof lastCharMessage !== 'undefined') {
    ctxText = lastCharMessage || '';
  }
}
```

**错误写法（会导致永远匹配不到关键词）：**

```javascript
// ❌ 仅依赖 getChatMessages，preprocessing 阶段常为 0 条
var userMessages = getChatMessages(-1, -1, 'user');
var messageText = userMessages.length > 0 ? userMessages[userMessages.length - 1].message : '';
```

### 2.4 提示词模板语法插件（EjsTemplate）

路径：扩展程序 → **提示词模板**

- [ ] **处理生成内容**（`generate_enabled`）已开启
- [ ] **立即加载世界书**（`preload_worldinfo_enabled`）已开启 ← 动态控制器强烈建议开
- [ ] **生成时注入 GENERATE 世界书条目**（`generate_loader_enabled`）已开启

### 2.5 角色世界书绑定

- [ ] **主要世界书**：角色主设定（如 `咒术回战 - 沙盒 5.2.0`）
- [ ] **附加世界书**：勾选 `咒术回战同人创作库_EJS优化版`（Shift+点击 🌍 角色世界书按钮）
- [ ] 知悉：**附加世界书不会随角色卡导出**，换聊天/换设备需重新绑定
- [ ] 可选兜底：将 EJS 世界书加入 **全局世界书**（与附加绑定二选一或并存均可，但控制器逻辑仍依赖 getwi 世界书名）

---

## 3. 运行时校验清单（用户反馈「没效果」时）

按顺序执行，**上一步失败则先修上一步**。

### Step 0：确认现象类型

| 用户描述 | 优先怀疑 |
|----------|----------|
| 完全不知道术式设定 | A / B / C 全流程 |
| AI 提了名字但细节胡编 | C 部分成功或条目太短 |
| AI 明确说「这个世界没有 XX」 | 提示词里没进条目正文（B 或 C） |
| 只有重新生成后才正常 | 旧楼层是修复前生成的，需 **/regenerate** |

### Step 1：绑定是否生效

在酒馆页面控制台（或 Chrome MCP + `TavernHelper`）：

```javascript
await TavernHelper.getCharWorldbookNames('current');
// 期望：{ primary: '咒术回战 - 沙盒 5.2.0', additional: ['咒术回战同人创作库_EJS优化版'] }
```

- [ ] `additional` 含 EJS 世界书名  
- [ ] 若为空：Shift+点击角色 🌍 → 附加世界书选 EJS 本 → 确定 → 保存聊天

**注意**：不要用「角色 JSON 里有没有 extra_worlds 字段」判断——ST 存储位置与导出字段不一致，`getCharWorldbookNames` 才是权威来源。

### Step 2：世界书条目与 patch 是否最新

```javascript
const wb = await TavernHelper.getWorldbook('咒术回战同人创作库_EJS优化版');
const c = wb.find(e => e.uid === 167);
({
  enabled: c.enabled,
  constant: c.strategy?.type === 'constant',
  hasPreprocessing: c.content.includes('@@preprocessing'),
  hasGetwiFix: c.content.includes('getwi(LOREBOOK_NAME'),
  hasLastUserMessageFix: c.content.includes('lastUserMessage'),
});
```

- [ ] `enabled: true`，策略为 constant（蓝灯）
- [ ] `hasGetwiFix: true`
- [ ] `hasLastUserMessageFix: true`（本次修复标记）

若 patch 过期：在项目根运行 `node src/咒术/二创库/scripts/patch_ejs_controller.js`，再导入 JSON 或用 `updateWorldbookWith` 热更新。

### Step 3：EJS 插件开关

```javascript
EjsTemplate.getFeatures();
// 重点：generate_enabled: true, preload_worldinfo_enabled: true
```

- [ ] 两项均为 `true`  
- [ ] 若为 false：`EjsTemplate.setFeatures({ preload_worldinfo_enabled: true, generate_enabled: true })` 并在 UI 中勾选持久化

### Step 4：控制器单测（最关键）

```javascript
const ejs = EjsTemplate;
ejs.setFeatures({ preload_worldinfo_enabled: true });
await ejs.refreshWorldInfo?.();

const ctx = await ejs.prepareContext({});
const wb = await TavernHelper.getWorldbook('咒术回战同人创作库_EJS优化版');
const controller = wb.find(e => e.uid === 167);

const out = await ejs.evalTemplate(controller.content, ctx);
({
  lastUserMessage: ctx.lastUserMessage,
  outLen: out.length,
  hasEntryBody: out.includes('五行属光') || out.includes('五行属土'), // 按测试关键词改
});
```

**判定标准：**

| 结果 | 含义 |
|------|------|
| `outLen` ≈ 17，仅 `@@preprocessing\n\n` | 关键词未匹配 → 查 Step 3 消息读取 / KEY_INDEX |
| `outLen` > 500 且 `hasEntryBody: true` | **控制器链路正常** |
| `getwi` 单测有内容，控制器无内容 | KEY_INDEX 名与条目 `name` 不一致，或关键词未命中 |

**辅助诊断（消息读取）：**

```javascript
const ctx = await EjsTemplate.prepareContext({});
({
  lastUserMessage: ctx.lastUserMessage,           // 应有用户最后一句
  cmsUserCount: ctx.getChatMessages(-1, -1, 'user').length, // preprocessing 中常为 0
});
```

### Step 5：提示词是否进生成（端到端）

- [ ] 发送含关键词的消息（如 `我想学帝皇侠`、`查看地虎侠能力`）
- [ ] 打开 **魔棒 → 提示词查看器**，搜索条目特征句（如 `五行属光`、`地虎召唤器`）
- [ ] 或对**修复前已生成的楼层**执行 `/regenerate`（旧回复不会 retroactive 更新）

**不可靠的检测方式（勿单独使用）：**

- `getWorldInfoPrompt('关键词')` — 不一定走完整 EJS preprocessing 管线
- `getWorldInfoActivatedData()` 里看不到 EJS 世界书 — 附加书条目可能只在 enabled 列表，不在 activated 采样里，**不代表失败**

---

## 4. 常见问题对照表

| # | 症状 | 根因 | 修复 |
|---|------|------|------|
| 1 | 绑了附加世界书，完全无术式 | `getChatMessages` 在 preprocessing 为空 | 增加 `lastUserMessage` fallback（见 2.3） |
| 2 | 同上 | `getwi('条目名')` 未指定世界书名 | 改为 `getwi(LOREBOOK_NAME, 条目名)` |
| 3 | getwi 单测 OK，控制器空 | `KEY_INDEX.name` ≠ 条目 `name` | 改 patch 脚本或条目 name 对齐 |
| 4 | 控制台 eval 正常，AI 仍胡写 | 该楼层是修复前生成 | `/regenerate` 或新发消息 |
| 5 | eval 始终 ~17 字节 | 未开「立即加载世界书」 | 开启 `preload_worldinfo_enabled` |
| 6 | 换聊天后失效 | 附加世界书未绑定到新聊天 | 重新 Shift+🌍 绑定附加书 |
| 7 | AI 拒绝跨作品能力 | 主世界书 `<Worldview_Boundary_and_Filter>` 拦截 | 术式条目进 prompt 后仍可能被 filter 曲解；需条目内强调「咒力版解释」或调整 filter 条目 |
| 8 | 导入 JSON 后仍旧逻辑 | ST 内世界书未更新 | 重新导入或 `updateWorldbookWith` 覆盖 uid=167 |

---

## 5. AI Agent 修复 SOP（复制即用）

```text
1. 读 getCharWorldbookNames('current') → 确认 additional 含目标世界书
2. 读 getWorldbook → uid=167 控制器 content 是否含 LOREBOOK_NAME + lastUserMessage
3. 读 EjsTemplate.getFeatures() → preload + generate 是否 true
4. prepareContext + evalTemplate(控制器) → outLen > 500 且含条目特征词
5. 失败则：
   - 缺 lastUserMessage → 跑 patch_ejs_controller.js 并热更新 ST
   - 缺 LOREBOOK_NAME → 同上
   - 缺 preload → setFeatures + UI 勾选
   - 缺绑定 → rebindCharWorldbooks / UI 附加世界书
6. 通过后：提示用户 regenerate 或发新消息，并用提示词查看器抽查
```

**项目内修复脚本：**

```bash
node src/咒术/二创库/scripts/patch_ejs_controller.js
```

输出：`src/咒术/二创库/咒术回战同人创作库_EJS优化版.json`（同步到桌面/导入 ST）。

**热更新单条目（浏览器控制台）：**

```javascript
await TavernHelper.updateWorldbookWith('咒术回战同人创作库_EJS优化版', entries =>
  entries.map(e => e.uid === 167 ? { ...e, content: '...新 content...' } : e),
  { render: 'immediate' }
);
await EjsTemplate.refreshWorldInfo?.();
```

---

## 6. 本次案例复盘（2026-06）

| 项目 | 内容 |
|------|------|
| 现象 | 附加世界书 UI 已勾选，发「我想学帝皇侠」AI 仍按世界观 filter 否认术式 |
| 误判 | 以为附加绑定未持久 / getwi 世界书名错误 |
| 实际 | ① `getwi(LOREBOOK_NAME, …)` 已在 ST 内正确；② **`getChatMessages` 返回 0 条**导致 KEY_INDEX 永不命中 |
| 修复 | 控制器增加 `lastUserMessage` / `lastCharMessage` fallback |
| 验证 | `evalTemplate` 输出 2108 字含「五行属光」；`/regenerate` 后 AI 引用帝皇铠甲 |
| 附带 | 开启 `preload_worldinfo_enabled`；确认全局/附加绑定均可，但 **getwi 世界书名仍必需** |

---

## 7. 相关文件

| 文件 | 用途 |
|------|------|
| `src/咒术/二创库/scripts/patch_ejs_controller.js` | 生成/更新控制器 EJS 与 KEY_INDEX |
| `src/咒术/二创库/咒术回战同人创作库_EJS优化版.json` | 128 条目世界书导出 |
| `.cursor/skills/st-三明月/reference-ejs.md` | getwi / @@preprocessing 语法 |
| `.cursor/skills/st-知识库/references/EJS动态内容控制器.md` | 控制器模式说明 |
| `@types/iframe/exported.ejstemplate.d.ts` | `EjsTemplate.getFeatures` / `refreshWorldInfo` |

---

## 8. 快速自检口令（给用户）

发消息后，在控制台粘贴：

```javascript
(async () => {
  const ctx = await EjsTemplate.prepareContext({});
  const c = (await TavernHelper.getWorldbook('咒术回战同人创作库_EJS优化版')).find(e => e.uid === 167);
  const out = await EjsTemplate.evalTemplate(c.content, ctx);
  console.info('最后用户消息:', ctx.lastUserMessage);
  console.info('控制器输出长度:', out.length);
  console.info('是否含术式正文:', /五行属|十影|地虎召唤器|帝皇铠甲/.test(out));
})();
```

- 长度 **> 500** 且 **含术式正文** → 控制器正常，若 AI 仍不对请 **重新生成该楼**  
- 长度 **≈ 17** → 按本文 §3 从 Step 1 重查
