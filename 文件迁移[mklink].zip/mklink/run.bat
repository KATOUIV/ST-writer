@echo off
setlocal EnableExtensions
cd /d "%~dp0"

net session >nul 2>&1
if %ERRORLEVEL%==0 goto elevated

echo Requesting administrator privileges...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -WorkingDirectory '%CD%' -Verb RunAs"
exit /b

:elevated
title Folder Junction Migrator [Admin]
echo [Admin] %CD%
python app.py
if errorlevel 1 (
  echo.
  echo App exited with error %ERRORLEVEL%
  pause
)
endlocal