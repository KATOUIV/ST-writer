---
name: st-插件
description: 当用户想开发 SillyTavern（酒馆）插件、基于 st-api-wrapper 扩展功能、或把想法变成可运行代码时调用。面向零代码基础用户，提供傻瓜式需求模板、能力对照表、可直接复制粘贴的插件模板，并引用完整 ST-API-Wrapper 文档。
---

<SUBAGENT-STOP>
If you were dispatched as a subagent to execute a specific task, skip this skill.
</SUBAGENT-STOP>

<EXTREMELY-IMPORTANT>
用户通常是**完全不懂代码**的普通人。本 skill 的目标不是教他写代码，而是让他**用自然语言描述需求**，你帮他生成能直接运行的插件。

必须做到：
1. **说人话**：避免专业术语，必要时用生活化比喻解释。
2. **给现成代码**：不要只给思路，必须输出完整文件内容（manifest.json + index.js / index.ts）。
3. **可复制粘贴**：用户拿到文件后，按步骤放进 SillyTavern 即可运行。
4. **先问清楚**：用下面的“需求描述模板”引导用户补充关键信息，避免反复修改。
</EXTREMELY-IMPORTANT>

## 一、什么时候用本 skill

- “我想做一个酒馆插件，实现 XXX 功能”
- “能不能帮我把这个功能封装成插件？”
- “我想用 st-api-wrapper 的 API 做 XXX，但不会写代码”
- 任何涉及 `ST_API.xxx.yyy()`、SillyTavern 扩展、UI 面板、斜杠指令、Function Calling、Hooks 的请求。

## 二、首次调用时的固定开场

不要直接开始写代码。先向用户展示下面这段话（或转述），让他填空：

```markdown
请用下面格式告诉我你想做什么：

1. 插件名字（英文，比如 my-cool-plugin）：
2. 插件想做什么？用一句话描述：
3. 用户怎么触发它？
   - 选项 A：在聊天里输入斜杠指令（比如 /myplugin）
   - 选项 B：在扩展设置里出现一个设置面板
   - 选项 C：自动监听某些事件（比如发送按钮被点击、AI 生成完成）
   - 选项 D：给 AI 增加一个可调用的工具（Function Calling）
   - 选项 E：修改酒馆界面（加按钮、改文字、插面板）
   - 选项 F：读写文件 / 执行命令 / 管理后端插件（需要后端权限）
   - 其他：____
4. 需要操作哪些数据？
   - 聊天记录 / 当前角色 / 世界书 / 预设 / 头像 / 文件 / 命令行 / 其他
5. 有没有特别的安全或权限要求？
   - 是否要在云酒馆/多用户环境使用？
   - 是否需要执行系统命令？（默认不建议开启）
```

## 三、能力对照表（你内部使用）

根据用户需求，从下面表格找到对应的 API 命名空间，然后去 `references/docs/<namespace>/` 读取具体文档。

| 用户想做的事 | 对应 API 命名空间 | 必读文档 |
|------------|----------------|---------|
| 让 AI 生成文字（后台/写入聊天/流式） | `prompt` | `references/docs/prompt/generate.md`、`buildRequest.md`、`get.md` |
| 在扩展设置里加面板 | `ui` | `references/docs/ui/registerSettingsPanel.md`、`registerExtensionsMenuItem.md`、`registerOptionsMenuItem.md` |
| 注册斜杠指令 / 执行已有指令 | `slashCommand` | `references/docs/slashCommand/register.md`、`execute.md`、`README.md` |
| 给 AI 增加可调用工具 | `functionCalling` | `references/docs/functionCalling/register.md`、`README.md` |
| 拦截发送/继续/再生按钮，监听生成事件 | `hooks` | `references/docs/hooks/install.md`、`README.md`、`intercept.md`、`observe.md` |
| 操作聊天记录（增删改查） | `chatHistory` | `references/docs/chatHistory/*.md` |
| 操作角色卡 | `character` | `references/docs/character/*.md` |
| 操作世界书 | `worldbook` | `references/docs/worldbook/*.md` |
| 操作预设/提示词 | `preset` | `references/docs/preset/*.md` |
| 操作头像 | `avatar` | `references/docs/avatar/*.md` |
| 读写文件 | `file` | `references/docs/file/*.md` |
| 执行系统命令 / 探测环境 | `command` | `references/docs/command/*.md`、`command-exec-集成步骤.md` |
| 管理后端 Server Plugin | `serverPlugin` | `references/docs/serverPlugin/*.md`、`server-plugin-manager-集成步骤.md` |
| 注册/调用服务端 API | `serverApi` | `references/docs/serverApi/*.md` |
| 操作变量/宏 | `variables` / `macros` | `references/docs/variables/*.md`、`references/docs/macros/*.md` |
| 正则脚本 | `regexScript` | `references/docs/regexScript/*.md` |
| 修改 DOM / 界面元素 | jQuery + DOM | `references/docs/DOM-定位与修改指南.md` |

**总览入口**：`references/docs/README.md`。

## 四、插件生成流程

当用户提供需求后，按以下步骤执行：

### 步骤 1：确认前置依赖

- 用户是否已安装 `st-api-wrapper` 插件？
  - 未安装：先给出安装指引（见下方“安装 st-api-wrapper”）。
  - 已安装：继续。
- 如果需求涉及后端命令 / server plugin 管理：提醒用户必须开启 `enableServerPlugins: true`，并说明风险。

### 步骤 2：读取必要文档

根据能力对照表，用 `Read` 工具读取相关 `references/docs/` 下的 markdown。

必须至少读：
- `references/docs/README.md`
- 相关命名空间下的 `README.md`（如果有）
- 具体会使用的 endpoint 文档（例如 `generate.md`、`register.md`）

读完后，不要逐字转述文档。只提炼用户需要知道的：**输入参数、返回值、一个可复制的示例**。

### 步骤 3：设计插件结构

向用户确认：
- 插件名称（英文，用于 manifest.json）
- 触发方式（斜杠 / 面板 / 自动 / 工具 / Hook）
- 是否需要 UI（HTML 面板 / 弹窗 / 按钮）
- 是否需要后端能力（默认尽量避开）

### 步骤 4：生成完整文件

必须输出至少两个文件：

1. **`manifest.json`**：插件入口清单。
2. **`index.js`**（或 `index.ts`，如果用户有构建环境）：插件逻辑。

如果用户没有 Node.js / TypeScript 构建环境，**优先给纯 JavaScript（index.js）**，告诉他放进 SillyTavern 就能跑。

如果用户有构建环境（npm/vite），可以给 TypeScript + manifest.json，并给出 `npm run build` 步骤。

#### manifest.json 模板

```json
{
  "display_name": "插件显示名称",
  "loading_order": 100,
  "js": "index.js",
  "css": "style.css",
  "author": "你的名字",
  "version": "1.0.0",
  "description": "一句话描述插件功能"
}
```

说明：
- `loading_order`：如果依赖 st-api-wrapper，建议写大于 10 的数字（st-api-wrapper 自身是 10，确保它先加载）。
- `js`：入口 JS 文件路径。
- `css`：可选，如果没有样式可以省略这一行。

#### index.js 最小模板

```javascript
// 插件入口：等待酒馆和 ST_API 就绪
async function initMyPlugin() {
  const ctx = window.SillyTavern?.getContext?.();
  if (!ctx) {
    console.warn('[MyPlugin] SillyTavern context not found');
    return;
  }

  const { eventSource, event_types } = ctx;

  // 等待 APP_READY 事件，避免 DOM 未加载就操作
  eventSource.on(event_types.APP_READY, async () => {
    // 检查 st-api-wrapper 是否已加载
    if (!window.ST_API) {
      console.warn('[MyPlugin] ST_API not found. Please install st-api-wrapper first.');
      return;
    }

    console.log('[MyPlugin] Loaded');

    // ===== 在这里写你的插件逻辑 =====
    // 示例：列出可用 API endpoint
    console.log('Available endpoints:', window.ST_API.listEndpoints());
  });
}

initMyPlugin();
```

### 步骤 5：给出安装步骤

用编号列表告诉用户：

1. 在 SillyTavern 目录下新建文件夹：
   - `SillyTavern/public/scripts/extensions/third-party/你的插件名/`
2. 把 `manifest.json` 和 `index.js` 复制进去。
3. 重启 SillyTavern，或去“管理扩展 → 重载扩展”。
4. 打开浏览器 F12 控制台，输入 `window.ST_API?.listEndpoints?.()` 检查 st-api-wrapper 是否加载。
5. 按你设计的方式测试插件功能。

### 步骤 6：安全与风险提示

如果插件涉及以下能力，必须明确提示：

- **执行系统命令**（`command.run`）：只能用于自己完全信任的本地环境；云酒馆/多用户场景严禁使用，否则可能被恶意利用。
- **读写文件**（`file.*`）：只读写插件自己的目录或用户明确指定的目录。
- **管理后端插件**（`serverPlugin.*`）：需要 `enableServerPlugins: true`。
- **覆盖/拦截原生 UI**：避免破坏酒馆默认功能，记得提供卸载/清理逻辑。

## 五、常见需求代码片段

这些片段可以直接嵌入生成的 `index.js`。

### 1. 注册斜杠指令

```javascript
await ST_API.slashCommand.register({
  name: 'hello',
  callback: (ctx) => {
    return `你好，${ctx.unnamedArgs || '世界'}！`;
  },
  helpString: '打招呼',
});
```

### 2. 在扩展设置里加简单面板

```javascript
await ST_API.ui.registerSettingsPanel({
  id: 'my-plugin.settings',
  title: '我的插件',
  content: {
    kind: 'html',
    html: '<p>插件设置内容</p><button class="menu_button" id="my-btn">点我</button>',
  },
});

// 绑定按钮事件
$(document).on('click', '#my-btn', () => {
  alert('按钮被点击');
});
```

### 3. 后台调用 AI 生成

```javascript
const res = await ST_API.prompt.generate({
  writeToChat: false,
  timeoutMs: 60000,
});
console.log('生成结果：', res.text);
```

### 4. 拦截发送按钮

```javascript
await ST_API.hooks.install({
  id: 'my-plugin.hooks',
  intercept: { targets: ['sendButton'], block: true },
  observe: { targets: ['generationLifecycle'] },
  broadcast: { target: 'both' },
});

window.addEventListener('st-api-wrapper:intercept:sendButton', async (e) => {
  console.log('发送按钮被拦截', e.detail);
  // 在这里做自定义逻辑
});
```

### 5. 给 AI 注册工具

```javascript
await ST_API.functionCalling.register({
  name: 'rollDice',
  displayName: '掷骰子',
  description: '当用户要求掷骰子时调用，返回 1-6 的随机数。',
  parameters: {
    $schema: 'http://json-schema.org/draft-04/schema#',
    type: 'object',
    properties: {
      sides: { type: 'number', description: '骰子面数', default: 6 },
    },
  },
  action: ({ sides = 6 }) => {
    return { result: Math.floor(Math.random() * sides) + 1 };
  },
});
```

## 六、引用文档说明

本 skill 附带完整原始文档在 `references/docs/` 目录下，包含：

- 所有 API endpoint 的输入输出说明和示例
- `command-exec-集成步骤.md`
- `server-plugin-manager-集成步骤.md`
- `DOM-定位与修改指南.md`
- `st-api-bridge-外部网站调用酒馆功能.md`

生成插件时，**必须主动读取这些文档**，确保代码参数与最新文档一致，不要凭记忆写。

## 七、输出规范

每次生成插件后，你的最终回复必须包含：

1. **功能一句话总结**。
2. **生成了哪些文件**，每个文件的作用。
3. **完整文件内容**（用代码块）。
4. **安装步骤**（编号列表）。
5. **如何使用**（比如输入什么斜杠指令、点哪个按钮）。
6. **安全提示**（如果涉及后端/命令/文件操作）。
7. **可选：下一步建议**（例如“如果你想加设置项，可以扩展 UI 面板”）。
