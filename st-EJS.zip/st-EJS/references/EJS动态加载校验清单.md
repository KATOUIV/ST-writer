# EJS 动态加载控制器 · 故障排查与校验清单

> **适用对象**：  
> - **EJS 按需加载**：`@@preprocessing` + `getwi`（二创库 / 同人创作库）  
> - **setvar / getvar 管线**：世界书写变量 + 预设读变量（沙盒主世界书 · 战斗思维链等）  
> **典型案例**：  
> - EJS：`咒术回战同人创作库_EJS优化版`（128 条：127 绿灯禁用 + 1 蓝灯控制器 uid=167）  
> - setvar：`咒术回战 - 沙盒 5.2.0` 中 `战斗思维链` + 预设 `⚔️战斗思维链`  
> **读者**：人类维护者 + AI Agent（按本文顺序排查，勿跳过前置条件）。

---

## 1. 机制速览（AI 必须先理解）

```text
用户消息含关键词
    ↓
控制器条目（蓝灯 constant + @@preprocessing）在生成前执行 EJS
    ↓
匹配 KEY_INDEX → await getwi(世界书名, 条目名)
    ↓
被加载的 selective 条目（可处于「禁用」）正文进入提示词
    ↓
AI 生成时能看见术式/设定正文
```

**三个独立环节，任一失败都会表现为「绑了世界书但没效果」：**

| 环节 | 失败时表象 |
|------|------------|
| A. 世界书挂载 | 控制器根本不会参与扫描 |
| B. EJS 插件 / `@@preprocessing` | 控制器不执行或输出为空 |
| C. 控制器逻辑（读消息 / 匹配 / getwi） | 控制器执行了但加载 0 条 |

---

## 2. 部署前校验清单（新建或导入时）

### 2.1 世界书结构

- [ ] **仅 1 条蓝灯控制器**（`constant: true`，`enabled: true`），内容以 `@@preprocessing` 开头
- [ ] **其余术式条目为绿灯 selective 且 `enabled: false`**（由 `getwi` 加载，不要指望 UI 里手动开灯）
- [ ] 控制器内 `KEY_INDEX[].name` 与条目 **`name` 字段**（不是 comment 备注）一致，否则 `getwi` 找不到
- [ ] `KEY_INDEX` 中 `keys` 与用户可能输入的词一致（含别名、简称，如「十影法」「十种影法术」）
- [ ] 控制器使用 **`<%- await getwi(...) %>`**，不是 `<%=`，且必须带 `await`

### 2.2 附加世界书 + getwi 世界书名（高频坑）

当 EJS 世界书挂在角色的 **附加世界书**，而 **主要世界书** 是另一本（如沙盒主世界书）时：

- [ ] **禁止**只写 `getwi('条目名')`（会只在主要世界书里查找 → 永远空）
- [ ] **必须**写 `getwi('咒术回战同人创作库_EJS优化版', '条目名')` 或等价显式世界书名
- [ ] 控制器顶部定义 `LOREBOOK_NAME` 常量，与 ST 中世界书名称 **完全一致**（含空格、下划线）

```javascript
var LOREBOOK_NAME = '咒术回战同人创作库_EJS优化版';
// ...
<%- await getwi(LOREBOOK_NAME, matchedNames[mi]) %>
```

### 2.3 读取用户消息（本次修复的核心）

在 `@@preprocessing` 阶段，`getChatMessages(-1, -1, 'user')` **可能返回空数组**，但 EJS 上下文里 **`lastUserMessage` 有值**。

- [ ] 控制器必须 **fallback 到 `lastUserMessage`**
- [ ] 可选：上下文 fallback 到 `lastCharMessage`（近期 AI 回复里也含关键词时）

```javascript
if (typeof messageText === 'undefined') {
  var userMessages = getChatMessages(-1, -1, 'user');
  var messageText = userMessages.length > 0
    ? userMessages[userMessages.length - 1].message
    : (typeof lastUserMessage !== 'undefined' ? lastUserMessage : '');
}

if (typeof ctxText === 'undefined') {
  var recent = getChatMessages(-3, -1);
  var ctxText = recent.map(function(m) { return m.message || ''; }).join(' ');
  if (!ctxText && typeof lastCharMessage !== 'undefined') {
    ctxText = lastCharMessage || '';
  }
}
```

**错误写法（会导致永远匹配不到关键词）：**

```javascript
// ❌ 仅依赖 getChatMessages，preprocessing 阶段常为 0 条
var userMessages = getChatMessages(-1, -1, 'user');
var messageText = userMessages.length > 0 ? userMessages[userMessages.length - 1].message : '';
```

### 2.4 提示词模板语法插件（EjsTemplate）

路径：扩展程序 → **提示词模板**

- [ ] **处理生成内容**（`generate_enabled`）已开启
- [ ] **立即加载世界书**（`preload_worldinfo_enabled`）已开启 ← 动态控制器强烈建议开
- [ ] **生成时注入 GENERATE 世界书条目**（`generate_loader_enabled`）已开启

### 2.5 角色世界书绑定

- [ ] **主要世界书**：角色主设定（如 `咒术回战 - 沙盒 5.2.0`）
- [ ] **附加世界书**：勾选 `咒术回战同人创作库_EJS优化版`（Shift+点击 🌍 角色世界书按钮）
- [ ] 知悉：**附加世界书不会随角色卡导出**，换聊天/换设备需重新绑定
- [ ] 可选兜底：将 EJS 世界书加入 **全局世界书**（与附加绑定二选一或并存均可，但控制器逻辑仍依赖 getwi 世界书名）

---

## 3. 运行时校验清单（用户反馈「没效果」时）

按顺序执行，**上一步失败则先修上一步**。

### Step 0：确认现象类型

| 用户描述 | 优先怀疑 |
|----------|----------|
| 完全不知道术式设定 | A / B / C 全流程 |
| AI 提了名字但细节胡编 | C 部分成功或条目太短 |
| AI 明确说「这个世界没有 XX」 | 提示词里没进条目正文（B 或 C） |
| 只有重新生成后才正常 | 旧楼层是修复前生成的，需 **/regenerate** |

### Step 1：绑定是否生效

在酒馆页面控制台（或 Chrome MCP + `TavernHelper`）：

```javascript
await TavernHelper.getCharWorldbookNames('current');
// 期望：{ primary: '咒术回战 - 沙盒 5.2.0', additional: ['咒术回战同人创作库_EJS优化版'] }
```

- [ ] `additional` 含 EJS 世界书名  
- [ ] 若为空：Shift+点击角色 🌍 → 附加世界书选 EJS 本 → 确定 → 保存聊天

**注意**：不要用「角色 JSON 里有没有 extra_worlds 字段」判断——ST 存储位置与导出字段不一致，`getCharWorldbookNames` 才是权威来源。

### Step 2：世界书条目与 patch 是否最新

```javascript
const wb = await TavernHelper.getWorldbook('咒术回战同人创作库_EJS优化版');
const c = wb.find(e => e.uid === 167);
({
  enabled: c.enabled,
  constant: c.strategy?.type === 'constant',
  hasPreprocessing: c.content.includes('@@preprocessing'),
  hasGetwiFix: c.content.includes('getwi(LOREBOOK_NAME'),
  hasLastUserMessageFix: c.content.includes('lastUserMessage'),
});
```

- [ ] `enabled: true`，策略为 constant（蓝灯）
- [ ] `hasGetwiFix: true`
- [ ] `hasLastUserMessageFix: true`（本次修复标记）

若 patch 过期：在项目根运行 `node src/咒术/二创库/scripts/patch_ejs_controller.js`，再导入 JSON 或用 `updateWorldbookWith` 热更新。

### Step 3：EJS 插件开关

```javascript
EjsTemplate.getFeatures();
// 重点：generate_enabled: true, preload_worldinfo_enabled: true
```

- [ ] 两项均为 `true`  
- [ ] 若为 false：`EjsTemplate.setFeatures({ preload_worldinfo_enabled: true, generate_enabled: true })` 并在 UI 中勾选持久化

### Step 4：控制器单测（最关键）

```javascript
const ejs = EjsTemplate;
ejs.setFeatures({ preload_worldinfo_enabled: true });
await ejs.refreshWorldInfo?.();

const ctx = await ejs.prepareContext({});
const wb = await TavernHelper.getWorldbook('咒术回战同人创作库_EJS优化版');
const controller = wb.find(e => e.uid === 167);

const out = await ejs.evalTemplate(controller.content, ctx);
({
  lastUserMessage: ctx.lastUserMessage,
  outLen: out.length,
  hasEntryBody: out.includes('五行属光') || out.includes('五行属土'), // 按测试关键词改
});
```

**判定标准：**

| 结果 | 含义 |
|------|------|
| `outLen` ≈ 17，仅 `@@preprocessing\n\n` | 关键词未匹配 → 查 Step 3 消息读取 / KEY_INDEX |
| `outLen` > 500 且 `hasEntryBody: true` | **控制器链路正常** |
| `getwi` 单测有内容，控制器无内容 | KEY_INDEX 名与条目 `name` 不一致，或关键词未命中 |

**辅助诊断（消息读取）：**

```javascript
const ctx = await EjsTemplate.prepareContext({});
({
  lastUserMessage: ctx.lastUserMessage,           // 应有用户最后一句
  cmsUserCount: ctx.getChatMessages(-1, -1, 'user').length, // preprocessing 中常为 0
});
```

### Step 5：提示词是否进生成（端到端）

- [ ] 发送含关键词的消息（如 `我想学帝皇侠`、`查看地虎侠能力`）
- [ ] 打开 **魔棒 → 提示词查看器**，搜索条目特征句（如 `五行属光`、`地虎召唤器`）
- [ ] 或对**修复前已生成的楼层**执行 `/regenerate`（旧回复不会 retroactive 更新）

**不可靠的检测方式（勿单独使用）：**

- `getWorldInfoPrompt('关键词')` — 不一定走完整 EJS preprocessing 管线
- `getWorldInfoActivatedData()` 里看不到 EJS 世界书 — 附加书条目可能只在 enabled 列表，不在 activated 采样里，**不代表失败**

---

## 4. 常见问题对照表

| # | 症状 | 根因 | 修复 |
|---|------|------|------|
| 1 | 绑了附加世界书，完全无术式 | `getChatMessages` 在 preprocessing 为空 | 增加 `lastUserMessage` fallback（见 2.3） |
| 2 | 同上 | `getwi('条目名')` 未指定世界书名 | 改为 `getwi(LOREBOOK_NAME, 条目名)` |
| 3 | getwi 单测 OK，控制器空 | `KEY_INDEX.name` ≠ 条目 `name` | 改 patch 脚本或条目 name 对齐 |
| 4 | 控制台 eval 正常，AI 仍胡写 | 该楼层是修复前生成 | `/regenerate` 或新发消息 |
| 5 | eval 始终 ~17 字节 | 未开「立即加载世界书」 | 开启 `preload_worldinfo_enabled` |
| 6 | 换聊天后失效 | 附加世界书未绑定到新聊天 | 重新 Shift+🌍 绑定附加书 |
| 7 | AI 拒绝跨作品能力 | 主世界书 `<Worldview_Boundary_and_Filter>` 拦截 | 术式条目进 prompt 后仍可能被 filter 曲解；需条目内强调「咒力版解释」或调整 filter 条目 |
| 8 | 导入 JSON 后仍旧逻辑 | ST 内世界书未更新 | 重新导入或 `updateWorldbookWith` 覆盖 uid=167 |
| 9 | 预设有 `⚔️战斗思维链` 但 AI 不写 BP | 误判为「没加载」；实为 **注入成功 + 输出格式被覆盖** | 见 §9：查 getvar 长度、预设开关与顺序、`/regenerate` |
| 10 | 把战斗思维链改成 EJS getwi 后 preset 失效 | getwi 只注入纯文本，**不执行** `{{setvar::}}` 宏 | 战斗思维链必须走 **ST 原生 selective + setvar**，见 §9.1 |
| 11 | 热更新 HTTP 9876 连上旧内容 | 端口被旧进程占用，fetch 到的是别的 JSON | 换端口或 `node patch_ejs_sandbox.js` 后 `updateWorldbookWith`，见 §9.7 |

---

## 5. AI Agent 修复 SOP（复制即用）

```text
1. 读 getCharWorldbookNames('current') → 确认 additional 含目标世界书
2. 读 getWorldbook → uid=167 控制器 content 是否含 LOREBOOK_NAME + lastUserMessage
3. 读 EjsTemplate.getFeatures() → preload + generate 是否 true
4. prepareContext + evalTemplate(控制器) → outLen > 500 且含条目特征词
5. 失败则：
   - 缺 lastUserMessage → 跑 patch_ejs_controller.js 并热更新 ST
   - 缺 LOREBOOK_NAME → 同上
   - 缺 preload → setFeatures + UI 勾选
   - 缺绑定 → rebindCharWorldbooks / UI 附加世界书
6. 通过后：提示用户 regenerate 或发新消息，并用提示词查看器抽查

战斗 BP / combat_driver 问题 → 改走 §9（setvar/getvar，不是 EJS evalTemplate）
```

**项目内修复脚本：**

```bash
node src/咒术/二创库/scripts/patch_ejs_controller.js
```

输出：`src/咒术/二创库/咒术回战同人创作库_EJS优化版.json`（同步到桌面/导入 ST）。

**热更新单条目（浏览器控制台）：**

```javascript
await TavernHelper.updateWorldbookWith('咒术回战同人创作库_EJS优化版', entries =>
  entries.map(e => e.uid === 167 ? { ...e, content: '...新 content...' } : e),
  { render: 'immediate' }
);
await EjsTemplate.refreshWorldInfo?.();
```

---

## 6. 本次案例复盘（2026-06）

| 项目 | 内容 |
|------|------|
| 现象 | 附加世界书 UI 已勾选，发「我想学帝皇侠」AI 仍按世界观 filter 否认术式 |
| 误判 | 以为附加绑定未持久 / getwi 世界书名错误 |
| 实际 | ① `getwi(LOREBOOK_NAME, …)` 已在 ST 内正确；② **`getChatMessages` 返回 0 条**导致 KEY_INDEX 永不命中 |
| 修复 | 控制器增加 `lastUserMessage` / `lastCharMessage` fallback |
| 验证 | `evalTemplate` 输出 2108 字含「五行属光」；`/regenerate` 后 AI 引用帝皇铠甲 |
| 附带 | 开启 `preload_worldinfo_enabled`；确认全局/附加绑定均可，但 **getwi 世界书名仍必需** |

---

## 7. 相关文件

| 文件 | 用途 |
|------|------|
| `src/咒术/二创库/scripts/patch_ejs_controller.js` | 生成/更新控制器 EJS 与 KEY_INDEX |
| `src/咒术/二创库/咒术回战同人创作库_EJS优化版.json` | 128 条目世界书导出 |
| `src/咒术/世界书EJS版/scripts/patch_ejs_sandbox.js` | 沙盒主世界书 EJS 控制器 + 战斗思维链 selective 配置 |
| `src/咒术/世界书/战斗思维链.txt` | 战斗 BP 规则源文件（setvar 正文） |
| `src/咒术/世界书/🗑️清空局部变量(别关).txt` | 每轮清空 `combat_driver` 等局部变量 |
| `src/咒术/世界书EJS版/咒术回战 - 沙盒 5.2.0.json` | 沙盒主世界书导出（含 EJS 控制器 uid=995581） |
| `.cursor/skills/st-三明月/reference-ejs.md` | getwi / @@preprocessing 语法 |
| `.cursor/skills/st-知识库/references/EJS动态内容控制器.md` | 控制器模式说明 |
| `@types/iframe/exported.ejstemplate.d.ts` | `EjsTemplate.getFeatures` / `refreshWorldInfo` |

---

## 8. 快速自检口令（给用户）

发消息后，在控制台粘贴：

```javascript
(async () => {
  const ctx = await EjsTemplate.prepareContext({});
  const c = (await TavernHelper.getWorldbook('咒术回战同人创作库_EJS优化版')).find(e => e.uid === 167);
  const out = await EjsTemplate.evalTemplate(c.content, ctx);
  console.info('最后用户消息:', ctx.lastUserMessage);
  console.info('控制器输出长度:', out.length);
  console.info('是否含术式正文:', /五行属|十影|地虎召唤器|帝皇铠甲/.test(out));
})();
```

- 长度 **> 500** 且 **含术式正文** → 控制器正常，若 AI 仍不对请 **重新生成该楼**  
- 长度 **≈ 17** → 按本文 §3 从 Step 1 重查

---

## 9. 战斗思维链 · setvar / getvar 管线（沙盒主世界书）

> **与 §1–§8 的 EJS getwi 是两套机制。** 战斗 BP 规则必须经 **ST 原生宏** 写入聊天变量，再由 **预设** 读出；不能指望 EJS `getwi` 注入的纯文本去填充 `{{getvar::combat_driver}}`。

### 9.1 何时用 setvar，何时用 EJS getwi

| 需求 | 推荐机制 | 原因 |
|------|----------|------|
| 术式/地点等大段设定按需进 prompt | EJS 控制器 + `getwi` | 省 token，条目可保持「禁用」由控制器加载 |
| 规则要进 **预设提示词位**（如 AI 响应配置里的独立条目） | 世界书 `{{setvar::变量名::…}}` + 预设 `{{getvar::变量名}}` | getwi 输出**不会**再跑 ST 宏；preset 读不到变量 |
| 每轮开关型规则（战斗才开） | selective 绿灯 + setvar | 关键词命中才 setvar；非战斗轮清空变量 |

**错误改造（曾导致 preset 永远空）：**

```text
战斗思维链 改为 EJS getwi 注入 → 正文进 prompt 但 combat_driver 变量仍为空
→ 预设 {{getvar::combat_driver}} 注入 0 字 → AI 看不到 BP 规则
```

**正确分工（沙盒 5.2.0）：**

- `战斗思维链`：**不在** EJS 控制器 `KEY_INDEX` 里；`selective: true`，`disable: false`，`constant: false`
- EJS 控制器 uid=995581：只负责其余 261 条 selective + 4 条 lazy constant 的 `getwi`

### 9.2 两阶段注入架构

```text
每轮生成前（世界书扫描，按 order 大致顺序）：
  🗑️清空局部变量 (order≈3760)
    → {{setvar::combat_driver::}}  清空
  战斗思维链 (order≈3820, selective 绿灯, 战斗关键词命中)
    → {{setvar::combat_driver::…BP 规则全文…}}
       （宏执行后写入 chatMetadata.variables）

预设组装（AI 响应配置）：
  ⚔️战斗思维链  （内容：{{getvar::combat_driver}}，须开启）
    → 把变量里的 BP 规则注入 system 提示词（Inspect 约 994 tokens）

AI 输出：
  应在回复最前写 <combat_driver>…有效BP=…━━ 3.对抗判定 ━━…</combat_driver>
  正文 / story_driver 在其后
```

**战斗关键词（selective key，正则）：**  
`/战斗|对战|搏斗|打架|进攻|攻击|殴打|对决|搏击|厮杀|领域展开|术式|咒灵|咒术师|体术|咒力|祓除|必杀|反击|战斗吧/`

### 9.3 部署与调优清单

**世界书（`patch_ejs_sandbox.js` 会一并处理）：**

- [ ] `战斗思维链`：`selective: true`，`disable: false`，**不要**放进 EJS `KEY_INDEX`
- [ ] `🗑️清空局部变量`：**常开**，order **低于** 战斗思维链（先清空再 set）
- [ ] 正文源文件：`src/咒术/世界书/战斗思维链.txt` 以 `{{setvar::combat_driver::` 包裹
- [ ] 改 txt 后运行：`node src/咒术/世界书EJS版/scripts/patch_ejs_sandbox.js`

**预设（AI 响应配置 · 需人工核对）：**

- [ ] 存在条目 **`⚔️战斗思维链`**，内容为 **`{{getvar::combat_driver}}`**（仅此一行即可）
- [ ] 该条目 **开关为开启**（灰色关闭 = 整段 BP 规则不进 prompt，即使 setvar 已成功）
- [ ] **顺序调优（重要）**：将 `⚔️战斗思维链` 拖到 **`🧠思维链-故事模式` 之后**  
  故事模式模板内也含 `<combat_driver>`（D&D/叙事式），排在后面时 BP 规则更易成为「最后指令」
- [ ] 条目内可加 **【优先级】/【禁止输出】** 文案（已写入 `战斗思维链.txt`），强化对故事模板的覆盖

**正文调优要点（`战斗思维链.txt`）：**

- [ ] 顶部声明优先级高于故事模式 combat 模板
- [ ] 明确 **禁止**【参战方】【环境】【战况推演】、HP/d20 等替代格式
- [ ] 合规自检：输出块内必须出现 `━━ 1.初始化 ━━`、`有效BP=`、`━━ 3.对抗判定 ━━`

### 9.4 运行时自检（按顺序，上一步失败先修上一步）

#### Step A：区分「没注入」还是「注入了但 AI 不照做」

| 用户描述 | 优先怀疑 |
|----------|----------|
| 预设里明明有 ⚔️，AI 完全像没规则 | 预设 **关闭** 或 getvar 长度为 0 |
| Prompt 里能看见 BP/有效BP，AI 仍写【战况推演】 | **注入成功**；故事模式/历史回复格式覆盖 → 调顺序 + `/regenerate` |
| 改 EJS 后 preset 突然失效 | 战斗思维链被 getwi 化，setvar 未执行 |

#### Step B：变量与 getvar（控制台）

```javascript
(async () => {
  const ctx = SillyTavern.getContext();
  const v = ctx.substituteParams('{{getvar::combat_driver}}');
  const entry = (await TavernHelper.getWorldbook('咒术回战 - 沙盒 5.2.0'))
    .find(e => (e.comment || e.name) === '战斗思维链');

  console.table({
    'combat_driver 长度': v.length,
    '含【优先级】': v.includes('【优先级】'),
    '含有效BP': v.includes('有效BP'),
    '含 setvar 残留': v.includes('setvar::'), // 应为 false
    '战斗思维链 selective': entry?.selective,
    '战斗思维链 disable': entry?.disable,
    'key 非空': !!(entry?.key?.length),
  });
})();
```

**判定：**

| 结果 | 含义 |
|------|------|
| 长度 **> 1500** 且 `有效BP` 为 true | setvar + getvar **正常** |
| 长度 **0** | 未命中 selective / 清空顺序错 / 条目 disable |
| 长度正常但 AI 仍错 | 转 Step C、D |

#### Step C：预设开关与 Inspect

- [ ] AI 响应配置 → `⚔️战斗思维链` → **开启**
- [ ] 魔棒 → **提示词查看器**（或 Prompt Inspect）→ 搜索 **`有效BP`** 或 **`━━ 1.初始化`**
- [ ] 期望：在 **system 预设段** 能看见 BP 规则全文（约 994 tokens），而非仅在 AI 历史消息的 `<DisclosureTriangle>` 里

**不可靠：** 仅看 AI 回复里的 `<combat_driver>` 折叠块——那是 **输出格式**，不是 prompt 注入证明。

#### Step D：AI 输出合规（端到端）

```javascript
(async () => {
  const ctx = SillyTavern.getContext();
  const lastAi = [...ctx.chat].reverse().find(m => !m.is_user && !m.is_system);
  const mes = lastAi?.mes || '';
  const block = mes.match(/<combat_driver>([\s\S]*?)<\/combat_driver>/)?.[1] || '';

  console.table({
    '有 combat_driver 块': mes.includes('<combat_driver>'),
    '含有效BP': block.includes('有效BP'),
    '含初始化段': /━━\s*1\.初始化/.test(block),
    '叙事摘要违规': /【参战方】|【战况推演】/.test(block),
  });
})();
```

- 变量正常 + prompt 有 BP，但上表「叙事摘要违规」为 true → **`/regenerate` 该战斗楼**（旧楼在修复前已学会错误格式）
- 调优后仍失败 → 确认 `⚔️` 已排在故事思维链 **之后**，并检查聊天里是否有多条错误范例

#### Step E：Chrome MCP / Agent 快速探测（可选）

```javascript
// 在 SillyTavern 页 evaluate_script
async () => {
  const ctx = SillyTavern.getContext();
  return {
    char: ctx.characters[ctx.characterId]?.name,
    combat_driver_len: ctx.substituteParams('{{getvar::combat_driver}}').length,
    lastUserCombat: ctx.chat.filter(m => m.is_user).slice(-1)[0]?.mes?.slice(0, 80),
  };
};
```

### 9.5 现象对照表（战斗专用）

| # | 症状 | 根因 | 修复 |
|---|------|------|------|
| B1 | preset 有 ⚔️，getvar 长度 0 | selective 未命中 / 战斗思维链 disable / 清空在 set 之后 | 查关键词、order、`patch_ejs_sandbox.js` |
| B2 | getvar 正常，Inspect 无 BP | 预设 **⚔️ 关闭** | 打开开关 |
| B3 | Inspect 有 BP，AI 写【战况推演】 | 故事模式模板 + 历史错误输出 | ⚔️ 排到故事链后 + `/regenerate` |
| B4 | 改 EJS 后 getvar 变 0 | 战斗思维链改 getwi，setvar 不执行 | 恢复 selective+setvar，移出 KEY_INDEX |
| B5 | 热更新后规则仍是旧版 | 未跑 patch / ST 未 updateWorldbookWith | §9.7 |
| B6 | fetch 9876 热更内容不对 | 端口占用，读到旧 bundle | 换端口或直接用 TavernHelper 更新 |

### 9.6 案例复盘（2026-06 · 战斗 BP 不生效）

| 项目 | 内容 |
|------|------|
| 现象 | 用户称预设已有 `⚔️战斗思维链`；AI 战斗时不按 BP 计算，`<combat_driver>` 只有【参战方】【战况推演】 |
| 误判 | 「预设没加载 / 世界书没触发」 |
| 实际 | ① `combat_driver` 变量 **已写入**（~1659 字），`{{getvar::combat_driver}}` 替换正常；② 预设 Inspect **994 tokens**；③ **AI 未遵守** BP 格式——与 `🧠思维链-故事模式` 内 combat 模板冲突，且历史 2 条战斗回复均为叙事型 |
| 修复 | `战斗思维链.txt` 增加【优先级】【禁止输出】【合规自检】；`patch_ejs_sandbox.js` 保持战斗链 **selective+setvar、不进 EJS**；热更新 ST 世界书 |
| 验证 | 控制台 getvar 含 `有效BP`；用户侧：开启 ⚔️、调整预设顺序、`/regenerate` 战斗楼 |
| 附带 | `getWorldInfoPrompt()` 常返回空仍可能 **不影响** setvar——以 `substituteParams('{{getvar::…}}')` 为准 |

### 9.7 热更新与 patch

**推荐流程（改 `战斗思维链.txt` 后）：**

```bash
node src/咒术/世界书EJS版/scripts/patch_ejs_sandbox.js
```

**浏览器热更新（无需整本 reimport）：**

```javascript
// 将下方 CONTENT 替换为 战斗思维链.txt 全文
const CONTENT = `{{setvar::combat_driver::\n…\n}}`;

await TavernHelper.updateWorldbookWith('咒术回战 - 沙盒 5.2.0', entries =>
  entries.map(e =>
    (e.comment || e.name) === '战斗思维链'
      ? {
          ...e,
          content: CONTENT,
          disable: false,
          selective: true,
          constant: false,
          enabled: true,
        }
      : e,
  ),
  { render: 'immediate' },
);
await EjsTemplate.refreshWorldInfo?.();
```

**HTTP 临时同步（开发用，注意端口）：**

- 可用本地静态服务提供 `battle_sync.txt`；**9876 若已被占用**会 silently 读到旧文件 → 优先 `updateWorldbookWith` 或换端口
- 热更新时 **只改 content 不够** 时：确认 `selective` / `disable` / `key` 未被 UI 改坏

### 9.8 AI Agent SOP（战斗思维链）

```text
1. substituteParams('{{getvar::combat_driver}}') → 长度 > 1500 且含 有效BP？
   否 → getWorldbook 查 战斗思维链 selective/disable/key；跑 patch_ejs_sandbox.js；热更新
2. 预设 ⚔️战斗思维链 是否开启？Prompt Inspect 能否搜到 有效BP？
   否 → 提示用户开预设开关
3. 是 → 查 AI 最后回复 combat_driver 块是否含 有效BP
   否 → 预设顺序（⚔️ 在故事链后）+ /regenerate；检查战斗思维链.txt 禁止叙事格式文案
4. 勿将 战斗思维链 放入 EJS KEY_INDEX 或改为纯 getwi
```

### 9.9 用户快速自检口令

发 **含战斗关键词** 的消息后，控制台粘贴：

```javascript
(async () => {
  const ctx = SillyTavern.getContext();
  const v = ctx.substituteParams('{{getvar::combat_driver}}');
  console.info('── setvar / getvar ──');
  console.info('combat_driver 长度:', v.length, '（期望 >1500）');
  console.info('含有效BP:', v.includes('有效BP'));
  console.info('含【优先级】:', v.includes('【优先级】'));
  console.info('── 下一步 ──');
  if (v.length < 100) console.warn('变量空 → 查世界书 selective / 关键词');
  else if (!v.includes('有效BP')) console.warn('内容异常 → 热更新 战斗思维链.txt');
  else console.info('注入正常 → 若 AI 仍错：开 ⚔️预设、调顺序、/regenerate 战斗楼');
})();
```
