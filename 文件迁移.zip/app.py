"""文件夹联接迁移工具 — 图形界面。"""

from __future__ import annotations

import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from junction_core import JunctionError, migrate_and_link, resolve_final_destination


class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("文件夹联接迁移")
        self.minsize(560, 420)
        self.configure(bg="#1a1f24")
        self._build_style()
        self._build_ui()

    def _build_style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background="#1a1f24")
        style.configure("Card.TFrame", background="#242b33")
        style.configure(
            "Title.TLabel",
            background="#1a1f24",
            foreground="#e8eef4",
            font=("Segoe UI Semibold", 16),
        )
        style.configure(
            "Hint.TLabel",
            background="#1a1f24",
            foreground="#8b9aab",
            font=("Segoe UI", 9),
        )
        style.configure(
            "Field.TLabel",
            background="#242b33",
            foreground="#c5d0db",
            font=("Segoe UI", 10),
        )
        style.configure(
            "Path.TEntry",
            fieldbackground="#151a1f",
            foreground="#e8eef4",
            insertcolor="#e8eef4",
            bordercolor="#3a4654",
            lightcolor="#3a4654",
            darkcolor="#3a4654",
            padding=8,
        )
        style.configure(
            "Accent.TButton",
            background="#3d8b6e",
            foreground="#ffffff",
            font=("Segoe UI Semibold", 11),
            padding=(16, 10),
        )
        style.map(
            "Accent.TButton",
            background=[("active", "#4aa07f"), ("disabled", "#3a4654")],
            foreground=[("disabled", "#8b9aab")],
        )
        style.configure(
            "Ghost.TButton",
            background="#2c3540",
            foreground="#e8eef4",
            font=("Segoe UI", 9),
            padding=(10, 6),
        )
        style.map("Ghost.TButton", background=[("active", "#3a4654")])

    def _build_ui(self) -> None:
        root = ttk.Frame(self, style="TFrame", padding=24)
        root.pack(fill=tk.BOTH, expand=True)

        ttk.Label(root, text="文件夹联接迁移", style="Title.TLabel").pack(anchor=tk.W)
        ttk.Label(
            root,
            text="把原文件夹迁到另一盘，再在原路径创建 mklink /J 联接，程序仍走原路径，实际文件在新位置。",
            style="Hint.TLabel",
            wraplength=500,
        ).pack(anchor=tk.W, pady=(6, 18))

        card = ttk.Frame(root, style="Card.TFrame", padding=16)
        card.pack(fill=tk.X)

        self.source_var = tk.StringVar()
        self.target_var = tk.StringVar()

        self._path_row(card, "原文件夹（要剪切出去的那个文件夹，迁移后变成联接）", self.source_var, 0)
        self._path_row(card, "目标位置（父目录即可，里面已有其他文件也没关系）", self.target_var, 1)

        tip = ttk.Label(
            root,
            text="示例：原 = C:\\...\\vm_bundles　　目标父目录 = E:\\0DontTouch\n会剪切到 E:\\0DontTouch\\vm_bundles，父目录里其它文件不动。\n操作前请先退出正在使用该文件夹的程序（如 Claude）。",
            style="Hint.TLabel",
            justify=tk.LEFT,
        )
        tip.pack(anchor=tk.W, pady=(14, 10))

        self.log = tk.Text(
            root,
            height=8,
            bg="#151a1f",
            fg="#9ec5b0",
            insertbackground="#e8eef4",
            relief=tk.FLAT,
            font=("Consolas", 9),
            wrap=tk.WORD,
        )
        self.log.pack(fill=tk.BOTH, expand=True, pady=(4, 12))
        self._append_log("就绪。选择两个文件夹后点击「开始迁移」。")

        self.run_btn = ttk.Button(root, text="开始迁移", style="Accent.TButton", command=self._on_run)
        self.run_btn.pack(anchor=tk.E)

    def _path_row(self, parent: ttk.Frame, label: str, var: tk.StringVar, row: int) -> None:
        ttk.Label(parent, text=label, style="Field.TLabel").grid(
            row=row * 2, column=0, columnspan=2, sticky=tk.W, pady=(0 if row == 0 else 12, 4)
        )
        entry = ttk.Entry(parent, textvariable=var, style="Path.TEntry")
        entry.grid(row=row * 2 + 1, column=0, sticky=tk.EW, padx=(0, 8))
        ttk.Button(
            parent,
            text="浏览…",
            style="Ghost.TButton",
            command=lambda: self._browse(var),
        ).grid(row=row * 2 + 1, column=1, sticky=tk.E)
        parent.columnconfigure(0, weight=1)

    def _browse(self, var: tk.StringVar) -> None:
        path = filedialog.askdirectory(title="选择文件夹")
        if path:
            var.set(str(Path(path)))

    def _append_log(self, text: str) -> None:
        self.log.insert(tk.END, text + "\n")
        self.log.see(tk.END)

    def _on_run(self) -> None:
        source = self.source_var.get().strip()
        target = self.target_var.get().strip()
        if not source or not target:
            messagebox.showwarning("提示", "请先选择原文件夹和目标文件夹。")
            return

        try:
            final = resolve_final_destination(source, target)
        except JunctionError as exc:
            messagebox.showerror("失败", str(exc))
            return

        if not messagebox.askokcancel(
            "确认迁移",
            f"将执行：\n1. 剪切原文件夹到落盘位置\n2. 在原路径创建目录联接\n\n原：{source}\n你选的目标：{target}\n实际落盘：{final}\n\n父目录里其它文件不会动。请确认没有程序正在占用原文件夹。",
        ):
            return

        self.run_btn.configure(state=tk.DISABLED)
        self._append_log(f"开始迁移… 落盘 → {final}")

        def worker() -> None:
            try:
                msg = migrate_and_link(source, target)
                self.after(0, lambda m=msg: self._on_success(m))
            except JunctionError as exc:
                err = str(exc)
                self.after(0, lambda m=err: self._on_fail(m))
            except Exception as exc:  # noqa: BLE001
                err = f"未预期错误：{exc}"
                self.after(0, lambda m=err: self._on_fail(m))

        threading.Thread(target=worker, daemon=True).start()

    def _on_success(self, msg: str) -> None:
        self._append_log(msg)
        self.run_btn.configure(state=tk.NORMAL)
        messagebox.showinfo("成功", msg)

    def _on_fail(self, msg: str) -> None:
        self._append_log("失败：" + msg)
        self.run_btn.configure(state=tk.NORMAL)
        messagebox.showerror("失败", msg)


def main() -> None:
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
