/** 每张 MVU 角色卡复制并修改 — st-副api 自适应生成时产出 */
export const cardConfig = {
  branding: {
    panelTitle: '{{CARD_NAME}} · 多 API',
    toastPrefix: '{{CARD_NAME}}多API',
    globalSettingsKey: '{{CARD_NAME}}多API',
    scriptId: '{{SLUG}}-dual-api',
  },

  worldbookEntries: {
    singleFormat: '[格式]单一api模式',
    dualMainFormat: '[格式]多api主api',
    varList: '变量列表',
    varRules: '[mvu_update]变量更新规则',
    varOutput: '[mvu_update]变量输出格式',
    initvar: 'MVU初始变量',
  },

  loreFiles: {
    singleFormat: '../格式/单一api.txt',
    dualMainFormat: '../格式/多api主api.txt',
    secondaryFormat: '../格式/多api副api.txt',
    varList: '../../MVU/变量列表.txt',
    varRules: '../../MVU/变量更新规则.yaml',
    varOutput: '../../MVU/变量输出格式.yaml',
  },

  triggerTag: '{{TRIGGER_TAG}}',
  variableTag: 'UpdateVariable',
  statusPlaceholder: 'StatusPlaceHolderImpl',
  secondaryGenPrefix: '{{SLUG}}-secondary-',

  /** 副 API 测试用例 scene */
  sampleScene:
    '（替换为本卡世界观的一小段 story_scene 正文，50～150 字）',
} as const;
