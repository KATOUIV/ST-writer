# 示例卡-简化版

这是一个虚构的 demo 冒险者卡，展示如何把单一 API 格式拆成多 API 主/副格式。所有路径均为示意，复制到真实卡时请替换为 {卡名}。

## 文件清单

| 文件 | 作用 |
|---|---|
| `变量列表.txt` | MVU 变量声明 |
| `变量更新规则.yaml` | 变量怎么变 |
| `变量输出格式.yaml` | UpdateVariable 必须长什么样 |
| `单一api.txt` | single 模式主 API 格式 |
| `多api主api.txt` | dual 模式主 API 格式 |
| `多api副api.txt` | dual 模式副 API 任务说明 |
| `intake-checklist-filled.yaml` | 填好的 intake 清单 |

## 使用方式

1. 把 `变量列表.txt`、`变量更新规则.yaml`、`变量输出格式.yaml` 放进真实卡的 `MVU/`。
2. 把 `单一api.txt`、`多api主api.txt`、`多api副api.txt` 放进真实卡的 `多API/格式/`。
3. 按 `intake-checklist-filled.yaml` 改 `card-config.template.ts`。
4. 按本 skill 的 `implementation/implementation-guide.md` 生成脚本并 `pnpm build`。
