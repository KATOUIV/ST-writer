---
name: st-副api
description: 在将 SillyTavern MVU 角色卡改造为「主 API 写剧情 + 副 API 写变量」的双通道架构时使用。触发症状：单一 API 漏写或乱写 UpdateVariable、变量与正文冲突、变量规则占用上下文导致叙事质量下降、需要把变量 Patch 从主生成中剥离。
---

# SillyTavern 副 API 设计 Skill

## Overview

把一次 AI 回复拆成两条链路：

| 通道 | 职责 | 输出 |
|---|---|---|
| 主 API | 小说家 / 导演 | 剧情、思维链、状态展示 |
| 副 API | 变量审计员 | 仅 `<UpdateVariable>` JSON Patch |

脚本在 `GENERATION_ENDED` 后提取剧情块 → 调用副 API → 合并正文与变量 → 写回楼层。

本 Skill 负责**设计与脚本实现**：三份格式 txt、世界书五条目、铁律提炼、代码模板、验收清单。webpack / Vue 工程底层细节仍可与 `st-车间` 配合。

## When to Use

- 新建 MVU 角色卡，计划主 API 只写剧情、副 API 专写变量
- 已有单 API 卡出现漏写 / 乱写 `<UpdateVariable>`、变量与正文冲突
- 用户提到：副 API、多 API、dual API、secondary API、变量审计员、主 API 只写剧情
- 需要把 `变量更新规则.yaml` 提炼成副 API 铁律

不要单独使用本 Skill：

- 纯文本卡 / 不写 MVU 变量 → `st-三明月` / `st-知识库`
- 需要从零搭 webpack / Vue 工程细节 → `st-车间`

## Prerequisites

用户侧必须已具备：

| 项 | 说明 |
|---|---|
| MVU 三件套 | `变量列表.txt`、`变量更新规则.yaml`、`变量输出格式.yaml` |
| 单一 API 格式 | 能跑通、含 `<UpdateVariable>` 的现有主格式 |
| triggerTag | 剧情块标签，默认 `<story_scene>` |
| 状态栏占位（可选） | `<StatusPlaceHolderImpl/>`，无状态栏则删除 |
| 酒馆助手环境 | `st-车间` 维护的 tavern_helper_template 工程，MVU 框架与角色脚本组总开关已启用 |

缺 MVU 三件套 → 先启用 `st-三明月` / `st-知识库`。

## Core Concepts

| 术语 | 含义 |
|---|---|
| `single` 模式 | 单一 API，主 API 同时写剧情 + `<UpdateVariable>` |
| `dual` 模式 | 多 API，主 API 只写剧情，副 API 写 `<UpdateVariable>` |
| `triggerTag` | 给副 API 的剧情块标签，默认 `<story_scene>` |
| `variableTag` | 变量块标签，固定 `<UpdateVariable>` |
| 世界书五条目 | `[格式]单一api模式`、`[格式]多api主api`、变量列表、`[mvu_update]变量更新规则`、`[mvu_update]变量输出格式` |
| 铁律 | 从变量更新规则提炼的 3~8 条硬性约束，写进 `多api副api.txt` |

## Quick Reference

### 模式切换表

| 模式 | `[格式]单一api模式` | `[格式]多api主api` | 变量列表 | 变量更新规则 | 变量输出格式 |
|---|---|---|---|---|---|
| single | ON | OFF | ON | ON | ON |
| dual | OFF | ON | OFF | OFF | OFF |

dual 模式下 MVU 三件套关闭是**正常设计**，勿手动打开。

### 三份格式文件分工

| 文件 | 进世界书 | 谁消费 |
|---|---|---|
| `单一api.txt` | ✅ | single 模式主 API |
| `多api主api.txt` | ✅ | dual 模式主 API |
| `多api副api.txt` | ❌ | 仅副 API，由脚本注入 |

### 完整文件树

```text
{卡名}/
├── MVU/
│   ├── 变量列表.txt
│   ├── 变量更新规则.yaml
│   └── 变量输出格式.yaml
└── 多API/
    ├── 格式/
    │   ├── 单一api.txt
    │   ├── 多api主api.txt
    │   └── 多api副api.txt
    └── 脚本/
        ├── index.ts
        ├── card-config.ts
        ├── orchestrator.ts
        ├── api-client.ts
        ├── merge-message.ts
        ├── prompt-builder.ts
        ├── lore-cache.ts
        ├── worldbook-toggle.ts
        ├── settings.ts
        ├── settings-ui.ts
        └── SettingsPanel.vue
```

## Implementation

### Step 0 · 收集信息

按 `./references/intake-checklist.yaml` 逐项填写：

| 项 | 示例 |
|---|---|
| 卡名 / slug | 朝仓葵 / aoi |
| MVU 三件套路径 | `MVU/` |
| 现有单一 API 格式 | 含 `<UpdateVariable>` 的完整格式 |
| triggerTag | `story_scene` |
| 是否有状态栏占位 | `<StatusPlaceHolderImpl/>` |
| 卡专属铁律 | 3~8 条 |

### Step 1 · 写单一 API 格式

如果已有，直接复制到 `多API/格式/单一api.txt`。没有的话，用 `./references/单一api.template.txt` 填空。

### Step 2 · 派生多 API 主格式

复制 `单一api.txt` → `多api主api.txt`，然后：

1. 删除所有 `<UpdateVariable>` 要求
2. 增加主 API 禁止项：禁止输出 `<UpdateVariable>`、`<Analysis>`、JSON Patch
3. 保留其余标签顺序不变

模板见 `./references/多api主api.template.txt`。

### Step 3 · 写多 API 副格式

用 `./references/多api副api.template.txt`，填入：

- `{{CARD_NAME}}`、`{{TRIGGER_TAG}}`
- 从 `变量更新规则.yaml` 提炼的 3~8 条铁律
- 冲突处理规则

铁律提炼规则：取带「禁止」「delta」「range」「特殊公式」的 check。

### Step 4 · 注册世界书五条目

在 `index.yaml` 加入与 `./references/card-config.template.ts` 中 `worldbookEntries` 同名的五条条目。脚本注册与工程 patch 见 **Code Implementation Step 13**。

### Step 5 · 验收

按 `./references/intake-checklist.yaml` 的 `acceptance` 与 `./examples/示例卡-简化版/` 逐项检查：

1. `pnpm build` 成功
2. 扩展设置出现 `{卡名} · 多 API` 面板
3. dual 模式下主 API 正文无 `<UpdateVariable>`
4. 合并后楼层 raw 含 `<UpdateVariable>`（通常需等待 60~90 秒）
5. MVU 面板变量实际变化

聊天楼层验收脚本（Chrome DevTools 控制台执行）：

```javascript
() => {
  const last = document.querySelector('#chat .mes:last-child, .mes.last_mes');
  const raw = last?.querySelector('.mes_text')?.innerText || '';
  return {
    hasStoryScene: /<story_scene>/i.test(raw),
    hasUpdateVariable: /<UpdateVariable>/i.test(raw),
    mainHasUV: (raw.match(/<story_scene>[\s\S]*?<\/story_scene>/i)?.[0] || '').includes('UpdateVariable'),
    tail: raw.slice(-400),
  };
}
```

通过标准：`hasStoryScene` true，`hasUpdateVariable` true，`mainHasUV` false。

## Code Implementation

本 Skill 也覆盖脚本实现侧。所有代码模板见 `./implementation/implementation-guide.md`。

### Step 6 · 复制代码模板

按 `./implementation/implementation-guide.md` 的章节，把对应代码块复制到 `多API/脚本/` 下同名文件：

```text
index.ts
orchestrator.ts
api-client.ts
merge-message.ts
prompt-builder.ts
lore-cache.ts
worldbook-toggle.ts
settings.ts
settings-ui.ts
SettingsPanel.vue
card-config.ts
```

### Step 7 · 填写 card-config

复制 `./references/card-config.template.ts` 为 `card-config.ts`，替换：

- `{{CARD_NAME}}` → 卡名
- `{{SLUG}}` → 英文 slug
- `{{TRIGGER_TAG}}` → 剧情块标签
- `loreFiles` 路径 → 相对 `多API/脚本/` 的实际路径

### Step 8 · 入口与事件编排

`index.ts` 等待 MVU 就绪后初始化设置、事件编排、设置面板。`orchestrator.ts` 监听 `GENERATION_ENDED`，提取 `triggerTag` 后调用副 API。详见 `./implementation/implementation-guide.md` 的 `index.ts` / `orchestrator.ts` 章节。

### Step 9 · 副 API 调用与合并

`api-client.ts` 负责 `generateRaw`、重试、回退；`merge-message.ts` 负责把 `<UpdateVariable>` 拼到主 API 正文末尾。详见 `./implementation/implementation-guide.md` 的 `api-client.ts` / `merge-message.ts` 章节。

### Step 10 · prompt 组装

`prompt-builder.ts` 按固定顺序注入：

1. 系统提示（`多api副api.txt`）
2. 变量更新规则
3. 变量列表
4. 变量输出格式
5. 当前 `stat_data` 快照（可选）
6. 近期剧情摘要（可选）
7. user 末条指令（本轮 `triggerTag` 正文）

详见 `./implementation/implementation-guide.md` 的 `prompt-builder.ts` 章节。

### Step 11 · 世界书切换

`worldbook-toggle.ts` 按 single/dual 启停五条目。核心逻辑：

```typescript
await updateWorldbookWith(wbName, entries =>
  entries.map(e => {
    const controlled = Object.values(config.worldbookEntries).includes(e.name);
    if (!controlled) return e;
    const shouldEnable = computeEnable(e.name, mode);
    return { ...e, enabled: shouldEnable };
  })
);
```

详见 `./implementation/implementation-guide.md` 的 `worldbook-toggle.ts` 章节。

### Step 12 · 设置面板

`settings.ts` 用 zod 定义 schema 并持久化；`settings-ui.ts` + `SettingsPanel.vue` 把面板挂到 `#extensions_settings2`。详见 `./implementation/implementation-guide.md` 的 `settings.ts` / `SettingsPanel.vue` 章节。

### Step 13 · 构建与发布

```bash
pnpm build
# 产物：dist/{卡名}/多API/脚本/index.js
# 复制到：脚本发布/{scriptId}.js
```

在 `index.yaml` 注册脚本条目，模板见 `./implementation/implementation-guide.md` 末尾的 `index.yaml 注册片段`。

## Examples

- 完整格式模板：`./references/单一api.template.txt`、`./references/多api主api.template.txt`、`./references/多api副api.template.txt`
- 配置模板：`./references/card-config.template.ts`
- 代码模板：`./implementation/implementation-guide.md`
- 最小可改实例：`./examples/示例卡-简化版/`

## Common Mistakes

| 错误 | 后果 | 修复 |
|---|---|---|
| dual 下 MVU 三件套仍 ON | 主 API 抢写变量，合并失败 | 脚本会自动关闭，勿手动打开 |
| `多api副api.txt` 注册进世界书 | 主 API 也能读到副 API 任务 | 只放 `多API/格式/`，不进世界书 |
| 世界书条目名与 `card-config` 不一致 | 模式切换失效 | 逐字核对 |
| triggerTag 在三份 txt / 代码中不一致 | 副 API 拿不到剧情 | 统一标签名 |
| 铁律太泛 | Patch 与正文不符 | 从 `变量更新规则.yaml` 提炼具体规则 |
| 主格式仍要求“更新变量” | 剥离警告、拖慢合并 | 彻底删除 UV 相关指令 |

## Self-Check

交付前逐项确认：

- [ ] `./references/intake-checklist.yaml` 已填完
- [ ] 三份格式 txt 已生成
- [ ] `多api副api.txt` 未注册世界书
- [ ] 五条目名称与 `card-config` 一致
- [ ] triggerTag 在三份 txt 与 `card-config` 中一致
- [ ] 铁律 ≤8 条且具体
- [ ] `./implementation/implementation-guide.md` 代码模板已复制并改好 `card-config.ts`
- [ ] `pnpm build` 成功
- [ ] `index.yaml` 已注册脚本条目
- [ ] 扩展设置出现 `{卡名} · 多 API` 面板
- [ ] dual 模式下主 API 正文无 `<UpdateVariable>`，合并后楼层 raw 含 `<UpdateVariable>`
- [ ] 已告知用户：缺 MVU 三件套找 `st-三明月`/`st-知识库`，工程细节找 `st-车间`
