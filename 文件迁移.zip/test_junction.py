"""自动化测试：父目录可非空、只剪切被映射文件夹。"""

from __future__ import annotations

import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from junction_core import (
    JunctionError,
    is_reparse_point,
    migrate_and_link,
    resolve_final_destination,
    unlink_junction,
)


def assert_true(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


def _cleanup(base: Path, link: Path | None = None) -> None:
    if link is not None and link.exists() and is_reparse_point(link):
        unlink_junction(link)
    shutil.rmtree(base, ignore_errors=True)


def test_exact_final_path() -> None:
    """目标写成最终完整路径。"""
    base = Path(tempfile.mkdtemp(prefix="junc_exact_"))
    source = base / "vm_bundles"
    target = base / "moved" / "vm_bundles"
    source.mkdir(parents=True)
    (source / "hello.txt").write_text("junction-ok", encoding="utf-8")
    (source / "sub").mkdir()
    (source / "sub" / "data.bin").write_bytes(b"\x00\x01\x02")
    try:
        msg = migrate_and_link(source, target)
        print(f"[exact] {msg}")
        assert_true(is_reparse_point(source), "应为联接")
        assert_true((source / "hello.txt").read_text(encoding="utf-8") == "junction-ok", "联接可读")
        assert_true((target / "hello.txt").read_text(encoding="utf-8") == "junction-ok", "目标可读")
        unlink_junction(source)
        assert_true((target / "hello.txt").exists(), "删联接不删数据")
        print("[exact] PASSED")
    finally:
        _cleanup(base, source)


def test_nonempty_parent() -> None:
    """目标是已有其他内容的父目录：只剪切原文件夹进去，其它文件不动。"""
    base = Path(tempfile.mkdtemp(prefix="junc_parent_"))
    parent = base / "0DontTouch"
    parent.mkdir(parents=True)
    (parent / "keep_me.txt").write_text("stay", encoding="utf-8")
    (parent / "Roaming").mkdir()
    (parent / "Roaming" / "x.txt").write_text("also-stay", encoding="utf-8")

    source = base / "Adobe"
    source.mkdir()
    (source / "app.dll").write_bytes(b"dll")

    final = parent / "Adobe"
    try:
        assert_true(
            resolve_final_destination(source, parent) == final,
            "父目录应解析为 父\\原名",
        )
        msg = migrate_and_link(source, parent)
        print(f"[parent] {msg}")

        assert_true(is_reparse_point(source), "原路径应为联接")
        assert_true(final.is_dir() and not is_reparse_point(final), "真实数据在父\\原名")
        assert_true((final / "app.dll").read_bytes() == b"dll", "剪切内容丢失")
        assert_true((source / "app.dll").read_bytes() == b"dll", "经联接应可读")

        # 父目录原有内容未被清空/破坏
        assert_true((parent / "keep_me.txt").read_text(encoding="utf-8") == "stay", "父目录文件被破坏")
        assert_true(
            (parent / "Roaming" / "x.txt").read_text(encoding="utf-8") == "also-stay",
            "父目录子文件夹被破坏",
        )
        print("[parent] PASSED")
    finally:
        _cleanup(base, source)


def test_conflict_same_name_in_parent() -> None:
    """父目录下已有同名非空文件夹时应失败。"""
    base = Path(tempfile.mkdtemp(prefix="junc_conflict_"))
    parent = base / "0DontTouch"
    parent.mkdir()
    (parent / "Adobe").mkdir()
    (parent / "Adobe" / "old.txt").write_text("old", encoding="utf-8")
    source = base / "Adobe"
    source.mkdir()
    (source / "new.txt").write_text("new", encoding="utf-8")
    try:
        try:
            migrate_and_link(source, parent)
            raise AssertionError("同名冲突应失败")
        except JunctionError as exc:
            print(f"[conflict] rejected: {exc}")
        assert_true((source / "new.txt").exists(), "失败后源数据应仍在")
        assert_true((parent / "Adobe" / "old.txt").exists(), "失败后目标旧数据应仍在")
        print("[conflict] PASSED")
    finally:
        _cleanup(base)


def test_reject_same_path() -> None:
    base = Path(tempfile.mkdtemp(prefix="junc_same_"))
    try:
        p = base / "a"
        p.mkdir()
        try:
            migrate_and_link(p, p)
            raise AssertionError("相同路径应失败")
        except JunctionError as exc:
            print(f"[same] rejected: {exc}")
        print("[same] PASSED")
    finally:
        _cleanup(base)


def test_workspace_local() -> None:
    """在软件设计目录内再跑一轮（含中文路径）。"""
    base = ROOT / "_local_test"
    if base.exists():
        link = base / "src_folder"
        if link.exists() and is_reparse_point(link):
            unlink_junction(link)
        shutil.rmtree(base, ignore_errors=True)

    parent = base / "0DontTouch"
    parent.mkdir(parents=True)
    (parent / "other").mkdir()
    (parent / "other" / "ok.txt").write_text("keep", encoding="utf-8")

    source = base / "src_folder"
    source.mkdir()
    (source / "note.txt").write_text("local-ok", encoding="utf-8")
    final = parent / "src_folder"
    try:
        msg = migrate_and_link(source, parent)
        print(f"[local] {msg}")
        assert_true(is_reparse_point(source), "本地联接失败")
        assert_true((final / "note.txt").read_text(encoding="utf-8") == "local-ok", "本地落盘失败")
        assert_true((parent / "other" / "ok.txt").read_text(encoding="utf-8") == "keep", "本地父目录被清")
        unlink_junction(source)
        print("[local] PASSED")
    finally:
        _cleanup(base, source if source.exists() else None)


if __name__ == "__main__":
    test_exact_final_path()
    test_nonempty_parent()
    test_conflict_same_name_in_parent()
    test_reject_same_path()
    test_workspace_local()
    print("ALL TESTS PASSED")
