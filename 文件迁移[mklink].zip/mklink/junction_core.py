"""目录联接迁移核心逻辑：剪切被映射文件夹 + mklink /J。"""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path


class JunctionError(Exception):
    """迁移或创建联接失败。"""


def is_reparse_point(path: Path) -> bool:
    """判断路径是否为联接/符号链接等重解析点。"""
    try:
        if path.is_symlink():
            return True
        if hasattr(path, "is_junction") and path.is_junction():
            return True
    except OSError:
        return False
    return False


def abspath(path: str | Path) -> Path:
    p = Path(path).expanduser()
    if not p.is_absolute():
        p = Path.cwd() / p
    return Path(os.path.abspath(str(p)))


def _norm_key(path: Path) -> str:
    return os.path.normcase(str(path).rstrip("\\/"))


def _is_same_path(a: Path, b: Path) -> bool:
    return _norm_key(a) == _norm_key(b)


def _is_under(child: Path, parent: Path) -> bool:
    """child 是否位于 parent 目录树内（含等于 parent）。"""
    c = _norm_key(child)
    p = _norm_key(parent)
    if c == p:
        return True
    prefix = p + os.sep
    return c.startswith(prefix)


def _is_nonempty_dir(path: Path) -> bool:
    return path.is_dir() and any(path.iterdir())


def resolve_final_destination(source: str | Path, target: str | Path) -> Path:
    """
    解析真实落盘路径。

    - 目标不存在：视为最终路径（如 E:\\0DontTouch\\Adobe）
    - 目标已存在且文件夹名与原文件夹相同：视为最终路径
    - 目标已存在且是别的目录（哪怕里面已有其他文件）：视为父目录，
      最终路径 = 目标 \\ 原文件夹名（如 E:\\0DontTouch\\Adobe）
    """
    src = abspath(source)
    dst = abspath(target)

    if not src.exists() or not src.is_dir():
        raise JunctionError(f"原文件夹不存在或不是文件夹：{src}")

    if not dst.exists():
        return dst

    if not dst.is_dir():
        raise JunctionError(f"目标不是文件夹：{dst}")

    # 选中的就是最终同名目录
    if dst.name.casefold() == src.name.casefold():
        return dst

    # 选中的是父目录（允许非空），剪切进去
    return dst / src.name


def create_junction(link_path: Path, target_path: Path) -> None:
    """在 link_path 创建指向 target_path 的目录联接（mklink /J）。"""
    if link_path.exists():
        raise JunctionError(f"联接位置已存在，无法创建：{link_path}")
    if not target_path.exists():
        raise JunctionError(f"目标文件夹不存在：{target_path}")
    if not target_path.is_dir():
        raise JunctionError(f"目标不是文件夹：{target_path}")

    result = subprocess.run(
        ["cmd", "/c", "mklink", "/J", str(link_path), str(target_path)],
        capture_output=True,
        text=True,
        encoding="mbcs",
        errors="replace",
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip()
        raise JunctionError(f"mklink 失败：{detail or f'exit {result.returncode}'}")


def move_tree(src: Path, dst: Path) -> None:
    """将 src 整体剪切到 dst（dst 为最终数据目录）。"""
    try:
        if dst.exists():
            if _is_nonempty_dir(dst):
                raise JunctionError(f"最终落盘位置已有内容，请换位置或先处理冲突：{dst}")
            for child in list(src.iterdir()):
                shutil.move(str(child), str(dst / child.name))
            src.rmdir()
            return

        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dst))
    except JunctionError:
        raise
    except PermissionError as exc:
        raise JunctionError(
            "拒绝访问（权限不足或文件被占用）。"
            "请用 run.bat 以管理员启动，并关闭正在使用该文件夹的程序后重试。\n"
            f"详情：{exc}"
        ) from exc
    except OSError as exc:
        hint = ""
        if src.exists() and dst.exists():
            hint = (
                "\n注意：可能已部分迁移（源和目标都还残留文件），"
                "请先核对两边内容再决定是继续手动合并还是回滚。"
            )
        raise JunctionError(f"剪切失败：{exc}{hint}") from exc


def migrate_and_link(source: str | Path, target: str | Path) -> str:
    """
    剪切原文件夹到目标侧，再在原路径创建联接。

    目标可以是：
    1) 最终路径：E:\\0DontTouch\\vm_bundles
    2) 父目录（可非空）：E:\\0DontTouch  → 实际落到 E:\\0DontTouch\\vm_bundles
    """
    src = abspath(source)
    dst_input = abspath(target)

    if not src.exists():
        raise JunctionError(f"原文件夹不存在：{src}")
    if not src.is_dir():
        raise JunctionError(f"原路径不是文件夹：{src}")
    if is_reparse_point(src):
        raise JunctionError(f"原路径已是联接/符号链接，请先解除：{src}")

    final = resolve_final_destination(src, dst_input)

    if _is_same_path(src, final):
        raise JunctionError("原文件夹与最终落盘路径不能相同")
    if _is_under(final, src):
        raise JunctionError("最终落盘路径不能放在原文件夹内部")
    if _is_under(src, dst_input) and not _is_same_path(src, dst_input):
        raise JunctionError("原文件夹不能在目标文件夹内部")

    if final.exists() and _is_nonempty_dir(final):
        raise JunctionError(f"最终落盘位置已有内容，请换位置或先处理冲突：{final}")

    move_tree(src, final)

    if src.exists():
        raise JunctionError(f"迁移后原路径仍存在，无法建联接：{src}")

    try:
        create_junction(src, final)
    except JunctionError:
        raise
    except OSError as exc:
        raise JunctionError(
            f"数据已迁到 {final}，但创建联接失败：{exc}\n"
            f"可手动执行：mklink /J \"{src}\" \"{final}\""
        ) from exc

    return f"完成：{src}  <<===>>  {final}"


def unlink_junction(link_path: str | Path) -> None:
    """删除联接本身（不删目标真实数据）。"""
    path = abspath(link_path)
    if not path.exists():
        raise JunctionError(f"路径不存在：{path}")
    if not is_reparse_point(path):
        raise JunctionError(f"不是联接，拒绝删除以免误删数据：{path}")
    path.rmdir()
