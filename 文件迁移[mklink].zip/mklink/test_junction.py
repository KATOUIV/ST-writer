"""工作区多轮自动化测试 + 结束清理。"""

from __future__ import annotations

import shutil
import sys
import tempfile
import threading
import tkinter as tk
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from app import is_admin
from junction_core import (
    JunctionError,
    abspath,
    is_reparse_point,
    migrate_and_link,
    resolve_final_destination,
    unlink_junction,
)


def assert_true(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


def _cleanup(base: Path, link: Path | None = None) -> None:
    if link is not None and link.exists() and is_reparse_point(link):
        unlink_junction(link)
    # 再扫一遍目录内可能残留的联接
    if base.exists():
        for p in sorted(base.rglob("*"), reverse=True):
            if p.is_dir() and is_reparse_point(p):
                try:
                    unlink_junction(p)
                except JunctionError:
                    pass
    shutil.rmtree(base, ignore_errors=True)


def test_exact_final_path() -> None:
    base = Path(tempfile.mkdtemp(prefix="junc_exact_"))
    source = base / "vm_bundles"
    target = base / "moved" / "vm_bundles"
    source.mkdir(parents=True)
    (source / "hello.txt").write_text("junction-ok", encoding="utf-8")
    (source / "sub").mkdir()
    (source / "sub" / "data.bin").write_bytes(b"\x00\x01\x02")
    try:
        msg = migrate_and_link(source, target)
        print(f"[exact] {msg}")
        assert_true(is_reparse_point(source), "应为联接")
        assert_true((source / "hello.txt").read_text(encoding="utf-8") == "junction-ok", "联接可读")
        assert_true((target / "hello.txt").read_text(encoding="utf-8") == "junction-ok", "目标可读")
        unlink_junction(source)
        assert_true((target / "hello.txt").exists(), "删联接不删数据")
        print("[exact] PASSED")
    finally:
        _cleanup(base, source)


def test_nonempty_parent() -> None:
    base = Path(tempfile.mkdtemp(prefix="junc_parent_"))
    parent = base / "0DontTouch"
    parent.mkdir(parents=True)
    (parent / "keep_me.txt").write_text("stay", encoding="utf-8")
    (parent / "Roaming").mkdir()
    (parent / "Roaming" / "x.txt").write_text("also-stay", encoding="utf-8")

    source = base / "Adobe"
    source.mkdir()
    (source / "app.dll").write_bytes(b"dll")
    final = parent / "Adobe"
    try:
        assert_true(resolve_final_destination(source, parent) == final, "父目录解析错误")
        msg = migrate_and_link(source, parent)
        print(f"[parent] {msg}")
        assert_true(is_reparse_point(source), "原路径应为联接")
        assert_true(final.is_dir() and not is_reparse_point(final), "真实数据应在父\\原名")
        assert_true((final / "app.dll").read_bytes() == b"dll", "剪切内容丢失")
        assert_true((source / "app.dll").read_bytes() == b"dll", "经联接应可读")
        assert_true((parent / "keep_me.txt").read_text(encoding="utf-8") == "stay", "父目录文件被破坏")
        assert_true(
            (parent / "Roaming" / "x.txt").read_text(encoding="utf-8") == "also-stay",
            "父目录子文件夹被破坏",
        )
        print("[parent] PASSED")
    finally:
        _cleanup(base, source)


def test_empty_same_name_target() -> None:
    """最终同名空目录可填入。"""
    base = Path(tempfile.mkdtemp(prefix="junc_empty_"))
    source = base / "vm_bundles"
    target = base / "dest" / "vm_bundles"
    source.mkdir()
    (source / "a.txt").write_text("a", encoding="utf-8")
    target.mkdir(parents=True)
    try:
        migrate_and_link(source, target)
        assert_true(is_reparse_point(source), "空同名目标应成功建联接")
        assert_true((target / "a.txt").read_text(encoding="utf-8") == "a", "内容应填入空目标")
        print("[empty-same-name] PASSED")
    finally:
        _cleanup(base, source)


def test_conflict_same_name_in_parent() -> None:
    base = Path(tempfile.mkdtemp(prefix="junc_conflict_"))
    parent = base / "0DontTouch"
    parent.mkdir()
    (parent / "Adobe").mkdir()
    (parent / "Adobe" / "old.txt").write_text("old", encoding="utf-8")
    source = base / "Adobe"
    source.mkdir()
    (source / "new.txt").write_text("new", encoding="utf-8")
    try:
        try:
            migrate_and_link(source, parent)
            raise AssertionError("同名冲突应失败")
        except JunctionError as exc:
            print(f"[conflict] rejected: {exc}")
        assert_true((source / "new.txt").exists(), "失败后源数据应仍在")
        assert_true((parent / "Adobe" / "old.txt").exists(), "失败后目标旧数据应仍在")
        print("[conflict] PASSED")
    finally:
        _cleanup(base)


def test_reject_same_path() -> None:
    base = Path(tempfile.mkdtemp(prefix="junc_same_"))
    try:
        p = base / "a"
        p.mkdir()
        try:
            migrate_and_link(p, p)
            raise AssertionError("相同路径应失败")
        except JunctionError as exc:
            print(f"[same] rejected: {exc}")
        print("[same] PASSED")
    finally:
        _cleanup(base)


def test_reject_target_inside_source() -> None:
    base = Path(tempfile.mkdtemp(prefix="junc_inside_"))
    source = base / "src"
    source.mkdir()
    (source / "x.txt").write_text("x", encoding="utf-8")
    nested = source / "nested_dest"
    try:
        try:
            migrate_and_link(source, nested)
            raise AssertionError("目标在源内部应失败")
        except JunctionError as exc:
            print(f"[inside] rejected: {exc}")
        assert_true((source / "x.txt").exists(), "拒绝后源应完整")
        print("[inside] PASSED")
    finally:
        _cleanup(base)


def test_reject_already_junction() -> None:
    base = Path(tempfile.mkdtemp(prefix="junc_already_"))
    src = base / "bag"
    src.mkdir()
    (src / "f.txt").write_text("f", encoding="utf-8")
    parent = base / "park_parent"
    parent.mkdir()
    try:
        migrate_and_link(src, parent)
        assert_true(is_reparse_point(src), "准备联接失败")
        try:
            migrate_and_link(src, base / "another")
            raise AssertionError("已是联接应失败")
        except JunctionError as exc:
            print(f"[already-junction] rejected: {exc}")
        print("[already-junction] PASSED")
    finally:
        _cleanup(base, src if src.exists() else None)


def test_gui_callback_closure() -> None:
    root = tk.Tk()
    root.withdraw()
    results: list[str] = []

    def on_fail(m: str) -> None:
        results.append(m)
        root.quit()

    def worker() -> None:
        try:
            raise JunctionError("目标文件夹非空，请换空目录或先清空")
        except JunctionError as exc:
            err = str(exc)
            root.after(0, lambda m=err: on_fail(m))
        except Exception as exc:  # noqa: BLE001
            err = f"未预期错误：{exc}"
            root.after(0, lambda m=err: on_fail(m))

    threading.Thread(target=worker, daemon=True).start()
    root.after(2000, root.quit)
    root.mainloop()
    root.destroy()
    assert_true(results == ["目标文件夹非空，请换空目录或先清空"], f"callback={results}")
    print("[gui-callback] PASSED")


def test_permission_error_wrapped() -> None:
    """PermissionError 应包装成 JunctionError，而不是裸冒泡。"""
    from junction_core import move_tree

    base = Path(tempfile.mkdtemp(prefix="junc_perm_"))
    src = base / "s"
    dst = base / "d"
    src.mkdir()
    (src / "a.txt").write_text("a", encoding="utf-8")
    try:
        # 猴子补丁 shutil.move
        import junction_core as jc

        real_move = shutil.move

        def boom(*_a, **_k):
            raise PermissionError(5, "拒绝访问", str(src / "a.txt"))

        jc.shutil.move = boom  # type: ignore[attr-defined]
        try:
            try:
                move_tree(src, dst)
                raise AssertionError("应抛 JunctionError")
            except JunctionError as exc:
                text = str(exc)
                assert_true("拒绝访问" in text or "占用" in text, f"文案不对: {text}")
                assert_true("未预期" not in text, "不应再是未预期错误")
                print(f"[perm-wrap] ok: {exc}")
        finally:
            jc.shutil.move = real_move  # type: ignore[attr-defined]
        print("[perm-wrap] PASSED")
    finally:
        _cleanup(base)


def test_workspace_chinese_path() -> None:
    """在本工作区（含中文路径）实测。"""
    base = ROOT / "_workspace_round"
    if base.exists():
        _cleanup(base)

    parent = base / "0DontTouch"
    parent.mkdir(parents=True)
    (parent / "other").mkdir()
    (parent / "other" / "ok.txt").write_text("keep", encoding="utf-8")

    source = base / "src_folder"
    source.mkdir()
    (source / "note.txt").write_text("local-ok", encoding="utf-8")
    (source / "中文目录").mkdir()
    (source / "中文目录" / "说明.txt").write_text("你好", encoding="utf-8")
    final = parent / "src_folder"
    try:
        msg = migrate_and_link(source, parent)
        print(f"[workspace] {msg}")
        assert_true(is_reparse_point(source), "本地联接失败")
        assert_true((final / "note.txt").read_text(encoding="utf-8") == "local-ok", "落盘失败")
        assert_true(
            (source / "中文目录" / "说明.txt").read_text(encoding="utf-8") == "你好",
            "中文路径经联接失败",
        )
        assert_true((parent / "other" / "ok.txt").read_text(encoding="utf-8") == "keep", "父目录被清")
        assert_true(abspath(ROOT).exists(), "工作区根应仍在")
        print("[workspace] PASSED")
    finally:
        _cleanup(base, source if source.exists() else None)


def test_run_bat_quoting() -> None:
    """run.bat 必须是 ASCII+CRLF，且用 -FilePath（不能用 -LiteralPath / UTF-8 中文）。"""
    raw = (ROOT / "run.bat").read_bytes()
    assert_true(all(b < 128 for b in raw), "run.bat 含非 ASCII，CMD 在中文系统会解析错乱")
    assert_true(b"\r\n" in raw, "run.bat 应使用 CRLF 换行")
    text = raw.decode("ascii")
    assert_true("WorkingDirectory '%CD%'" in text, "run.bat 应使用 %CD% 作为工作目录")
    assert_true("WorkingDirectory '%~dp0'" not in text, "不应再使用易转义的 %~dp0")
    assert_true("-FilePath" in text, "Start-Process 应使用 -FilePath")
    assert_true("-LiteralPath" not in text, "Start-Process 不能使用 -LiteralPath")
    assert_true("if %ERRORLEVEL%==0" in text, "应用 == 比较 ERRORLEVEL")
    print(f"[run.bat] admin helper is_admin={is_admin()}")
    print("[run.bat] PASSED")


def run_all() -> None:
    tests = [
        test_exact_final_path,
        test_nonempty_parent,
        test_empty_same_name_target,
        test_conflict_same_name_in_parent,
        test_reject_same_path,
        test_reject_target_inside_source,
        test_reject_already_junction,
        test_gui_callback_closure,
        test_permission_error_wrapped,
        test_workspace_chinese_path,
        test_run_bat_quoting,
    ]
    for fn in tests:
        fn()


def cleanup_artifacts() -> None:
    """清除工作区内测试残留。"""
    for name in ("_local_test", "_workspace_round", "_round_stress"):
        p = ROOT / name
        if p.exists():
            _cleanup(p)
            print(f"[cleanup] removed {p}")
    cache = ROOT / "__pycache__"
    if cache.exists():
        shutil.rmtree(cache, ignore_errors=True)
        print(f"[cleanup] removed {cache}")


if __name__ == "__main__":
    rounds = 3
    for i in range(1, rounds + 1):
        print(f"\n======== ROUND {i}/{rounds} ========")
        run_all()
        print(f"======== ROUND {i} PASSED ========")
    cleanup_artifacts()
    print("\nALL ROUNDS PASSED + CLEANED")
